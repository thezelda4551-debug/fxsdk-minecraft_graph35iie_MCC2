# Minecraft Casio Graph 35+E II (gint / fxSDK)

Compilation : `fxsdk build-fx`. Les nouvelles sources sont `src/craft.c` et `src/texture.c` (déjà dans CMakeLists.txt).
Les sauvegardes des anciennes versions sont refusées : choisir **NOUVEAU MONDE**.

## Commandes
| Touche | Action |
|---|---|
| HAUT / BAS | avancer / reculer |
| GAUCHE / DROITE | tourner |
| SHIFT / ALPHA | pas de côté gauche / droit |
| EXE | sauter (nager vers le haut dans l'eau) |
| F1 | frapper une créature, sinon casser le bloc visé |
| F2 | utiliser : établi, four, lit ; sinon manger ; sinon poser le bloc |
| F3 / F4 | case précédente / suivante de la hotbar |
| F5 | inventaire (36 cases) ; SHIFT+F5 : fabrication 2x2 |
| EXIT | pause (sauver, textures, inventaire) |

Inventaire : EXE prend / dépose / échange / fusionne un tas, SHIFT+EXE déplace vers la hotbar ou le stockage, F1 ouvre la fabrication.

## Ajouté dans cette version
- **Textures éditables** : menu principal ou pause > TEXTURES. Éditeur 8x8 pour chaque bloc (texture dans le monde) et pour chaque bloc/objet (icône d'inventaire). EXE = pixel, F1 = vider, F2 = inverser, F3/F4 = id précédent/suivant, F5 = bloc/icône, SHIFT+F1 = retour au défaut, EXIT = sauvegarde (fichier MCC2TEX).
- **Objet en main** : icône agrandie, balancement à la marche, coup de bras en frappant/posant.
- **Inventaire** complet : 9 cases hotbar + 27 cases, piles de 64, chiffres 3x5 lisibles, durabilité des outils.
- **Saut** corrigé : 1,27 bloc (Minecraft : 1,25). Dégâts de chute comme Minecraft (1 par bloc au-delà de 3).
- **Faim / régénération** : faim + saturation + épuisement (marche, saut, minage, combat, régénération). Soin rapide à 20 de faim avec saturation, soin lent dès 18, famine à 0. Nourriture : pomme, viande crue, steak, chair pourrie.
- **Crafting** : 25 recettes (planches, bâtons, établi, torches, four, grès, outils bois/pierre/fer/diamant). Recettes 3x3 : établi à moins de 4 blocs ou visé avec F2. Aucun ingrédient perdu si l'inventaire est plein.
- **Four** (F2 sur un four) : minerais fer/or, sable→verre, pavé→pierre, viande, bois→charbon, netherrack→briques ; combustible : charbon, planches, bois. Les minerais donnent maintenant le bloc de minerai (à cuire), la pierre donne du pavé, palier de pioche requis (bois < pierre < fer < diamant < obsidienne).
- **Combat** : portée 3,2 blocs, recul, délai entre coups, critique en chute, dégâts selon l'arme (poing 1, épée bois 5 … diamant 8), durabilité. Créatures : vache, cochon (butin viande), zombie (nuit/Nether), creeper (explose, détruit des blocs). Apparition de nuit, disparition de jour.
- **Ender Dragon** (dimension End) : 100 PV, 4 piliers d'obsidienne avec cristaux qui le soignent (à détruire en frappant), phases vol en cercle / charge / posé au centre (dégâts x2), barre de vie. À sa mort : portail de sortie, mémorisé dans la sauvegarde.
- **Sauvegarde optimisée** : seules les modifications du joueur (jusqu'à 512 blocs) sont écrites, le reste est regénéré depuis la graine. Résultat : fichier de quelques Ko, et les blocs posés/cassés ne sont plus perdus quand un chunk sort de la fenêtre active.
- **Eau** : océans, lacs, marais ; nage, noyade (10 bulles), voile sous l'eau, créatures qui flottent, pas d'apparition dans l'eau. Lave : dégâts et nage.
- **12 biomes** : plaine, forêt, désert, taïga, toundra, océan, plage, montagne, marais, jungle, savane, badlands. Terrain par bruit lisse, arbres sans coupure aux bords de chunks, grottes 3D avec lave au fond, diamants près du bas.
- **Structures** : maison de village (lit, établi, four, torche), puits, pyramide du désert (chambre + or), igloo, temple de jungle, portail en ruine (fonctionnel), forteresse du Nether, portail du Nether, piliers de l'End.
- **Dimensions** : portail Overworld → Nether → End → Overworld. Mourir dans l'End ou le Nether ramène à l'Overworld.

## Limites réelles (écran 128x64 monochrome, ~64 Ko de RAM)
- Les textures officielles de Minecraft sont sous copyright Mojang et ne peuvent pas être fournies ; de toute façon un bloc fait 8x8 pixels noir/blanc. L'éditeur permet de dessiner les vôtres.
- Le contenu "jusqu'à la 1.17" (centaines de blocs, mobs, biomes) ne tient pas. Ce projet couvre un socle jouable de 39 blocs et 26 objets ; ajouter un bloc = 1 define dans config.h + 1 texture dans render.c.
- Le crafting est une liste de recettes (pas de grille 3x3 à remplir). Pas de redstone, enchantements, villageois, arc/projectiles, enchantement, ni forteresse / bastion complets : le monde actif ne fait que 16x16 blocs sur 10 de haut.
- Le dragon est une version simplifiée (pas de souffle, pas d'œuf).
- Hunger : pas de sprint (pas de touche libre).

## Test
Le code a été compilé sur PC avec des stubs gint (gcc -Wall, ASan/UBSan) et simulé 9000 images sans erreur mémoire ; il n'a pas été compilé avec le vrai fxSDK ni testé sur calculatrice. Si le build échoue, envoyez le message d'erreur.
