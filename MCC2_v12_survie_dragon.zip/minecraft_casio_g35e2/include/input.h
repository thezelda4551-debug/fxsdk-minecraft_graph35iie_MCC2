#ifndef INPUT_H
#define INPUT_H
void input_begin_frame(void);
int input_down(int key);
void input_reset(void);
#endif
