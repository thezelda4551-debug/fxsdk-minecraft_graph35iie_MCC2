#ifndef SAVE_H
#define SAVE_H
int save_game(void);
int load_game(void);
int save_exists(void);
#endif
