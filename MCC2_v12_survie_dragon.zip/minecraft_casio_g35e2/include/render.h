#ifndef RENDER_H
#define RENDER_H
#include <stdint.h>
#define FACE_XP 0
#define FACE_XN 1
#define FACE_YP 2
#define FACE_YN 3
#define FACE_ZP 4
#define FACE_ZN 5
/* Coordonnees monde (blocs) + cle de tri (distance^2 / 256). */
typedef struct { int16_t x,y,z; uint8_t block,face_mask; uint16_t key; } VisibleBlock;
void render_init(void);
void render_frame(void);
unsigned render_visible_count(void);
const VisibleBlock *render_visible_list(void);
/* Texture 8x8 monochrome d'un bloc (1 = pixel noir). u,v dans 0..7, v=0 en haut. */
int render_texel(uint8_t id,int u,int v,int face);
#endif
