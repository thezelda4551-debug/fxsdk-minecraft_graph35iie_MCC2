#ifndef GAME_H
#define GAME_H
#include <stdint.h>
#define MOB_COW 0
#define MOB_ZOMBIE 1
#define MOB_CREEPER 2
#define MOB_PIG 3
#define MOB_CRYSTAL 4
void game_init(void);
void game_tick(void);
uint32_t game_time(void);
int game_daylight(void);
void game_draw_hud(void);
/* Creature i : position des pieds en 8.8, hurt = frames de flash, fuse = mèche du creeper */
int game_mob(int i,int *x,int *y,int *z,int *type,int *hurt,int *fuse);
int game_dragon(int *x,int *y,int *z,int *hurt);      /* 1 si le dragon est en vie */
int game_attack(void);                                /* 1 si une cible est a portee */
void game_clear_mobs(void);
void game_enter_dimension(int d);
void game_sleep(void);
void game_message(const char *s);
void game_export(uint32_t *time,uint8_t *flags);
void game_import(uint32_t time,uint8_t flags);
#endif
