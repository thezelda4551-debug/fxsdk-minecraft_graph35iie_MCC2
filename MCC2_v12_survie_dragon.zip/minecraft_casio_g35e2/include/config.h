#ifndef CONFIG_H
#define CONFIG_H
#define SCREEN_W 128
#define SCREEN_H 64
#define CHUNK_SIZE 8
#define ACTIVE_RADIUS 1
/* Quatre chunks (2x2) et 10 couches verticales pour tenir dans la RAM. */
#define ACTIVE_SIDE 2
#define ACTIVE_CHUNKS 4
#define WORLD_Y 10
#define CHUNK_VOLUME (CHUNK_SIZE * CHUNK_SIZE * WORLD_Y)
#define WORLD_SAVE_VERSION 11
#define SEA_LEVEL 3           /* l'eau remplit jusqu'a ce niveau (inclus) */
#define MAX_EDITS 512         /* blocs modifies par le joueur (sauvegarde par differences) */

/* Blocks */
#define BLOCK_AIR 0
#define BLOCK_GRASS 1
#define BLOCK_DIRT 2
#define BLOCK_STONE 3
#define BLOCK_SAND 4
#define BLOCK_WOOD 5
#define BLOCK_LEAVES 6
#define BLOCK_COAL 7
#define BLOCK_IRON 8
#define BLOCK_WATER 9
#define BLOCK_PLANKS 10
#define BLOCK_CRAFTING 11
#define BLOCK_FURNACE 12
#define BLOCK_GLASS 13
#define BLOCK_BED 14
#define BLOCK_TORCH 15
#define BLOCK_COBBLE 16
#define BLOCK_GRAVEL 17
#define BLOCK_GOLD 18
#define BLOCK_REDSTONE 19
#define BLOCK_SNOW 20
#define BLOCK_SANDSTONE 21
#define BLOCK_NETHERRACK 22
#define BLOCK_SOUL_SAND 23
#define BLOCK_GLOWSTONE 24
#define BLOCK_LAVA 25
#define BLOCK_QUARTZ 26
#define BLOCK_BASALT 27
#define BLOCK_ENDSTONE 28
#define BLOCK_OBSIDIAN 29
#define BLOCK_PORTAL 30
#define BLOCK_PURPUR 31
#define BLOCK_CHORUS 32
#define BLOCK_MAGMA 33
#define BLOCK_CACTUS 34
#define BLOCK_FLOWER 35
#define BLOCK_BRICKS 36
#define BLOCK_BEDROCK 37
#define BLOCK_TERRACOTTA 38
#define BLOCK_DIAMOND_ORE 39
#define LAST_BLOCK 39

/* Objets (inventaire uniquement) */
#define ITEM_STICK 40
#define ITEM_COAL 41
#define ITEM_IRON_INGOT 42
#define ITEM_GOLD_INGOT 43
#define ITEM_DIAMOND 44
#define ITEM_APPLE 45
#define ITEM_RAW_MEAT 46
#define ITEM_COOKED_MEAT 47
#define ITEM_ROTTEN 48
#define ITEM_PICKAXE_WOOD 50
#define ITEM_PICKAXE_STONE 51
#define ITEM_PICKAXE_IRON 52
#define ITEM_AXE_WOOD 53
#define ITEM_AXE_STONE 54
#define ITEM_AXE_IRON 55
#define ITEM_SHOVEL_WOOD 56
#define ITEM_SHOVEL_STONE 57
#define ITEM_SHOVEL_IRON 58
#define ITEM_SWORD_WOOD 59
#define ITEM_SWORD_STONE 60
#define ITEM_SWORD_IRON 61
#define ITEM_PICKAXE_DIAMOND 62
#define ITEM_AXE_DIAMOND 63
#define ITEM_SHOVEL_DIAMOND 64
#define ITEM_SWORD_DIAMOND 65
#define LAST_ID 65
#define NUM_IDS 66

#define MAX_FACES 260
#define MAX_VISIBLE_BLOCKS 96
/* Rendu : rayon de scan (blocs), focale (pixels), plan proche et hauteur des yeux (8.8) */
#define RENDER_RADIUS 5
#define FOCAL 60
#define NEAR_Z 48
#define EYE_HEIGHT 380
/* Camera : appui bref = petit pas, maintien = acceleration progressive (degres/image) */
#define TURN_MIN_DEG 2
#define TURN_MAX_DEG 6
#define TURN_RAMP_FRAMES 6
/* Inventaire : 9 cases de hotbar (0-8) + 27 cases de stockage (9-35) */
#define HOTBAR_SLOTS 9
#define INVENTORY_SLOTS 36
#define MAX_STACK 64
#define FP_SHIFT 8
#define FP_ONE (1 << FP_SHIFT)
#define MAX_MOBS 8
#define DAY_TICKS 18000
/* Physique : saut de 1.25 bloc comme Minecraft (apogee = somme des vitesses = 324/256) */
#define JUMP_V 72
#define GRAVITY 9
/* Faim / regeneration (unites : frames) */
#define HEAL_FAST 10
#define HEAL_SLOW 60
#define STARVE_FRAMES 60
#define DRAGON_HP 100
#endif
