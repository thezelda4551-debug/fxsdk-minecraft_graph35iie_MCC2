#ifndef WORLD_H
#define WORLD_H
#include <stdint.h>
#include "types.h"
void world_init(void);
uint8_t world_get(int x,int y,int z);
void world_set(int x,int y,int z,uint8_t id);
void world_tick_stream(int px,int py,int pz);
int world_save(void);
int world_load(void);
int world_has_save(void);
int world_solid(int x,int y,int z);
int world_loaded(int x,int z); /* 1 si le chunk de (x,z) est charge */
uint32_t world_seed(void);
int world_dimension(void);
void world_set_dimension(int dimension, int px, int pz);
void world_set_seed(uint32_t seed);
void world_rebuild(int px,int pz);                 /* regenere la fenetre apres un chargement */
int world_ground(int x,int z,int ymax);            /* y de la case ou se tenir, ou -1 */
void world_find_spawn(int *sx,int *sy,int *sz);    /* case de depart sure pres de (4,4) */
int world_biome(int x,int z);                      /* biome du sol (overworld) */
#define B_PLAINS 0
#define B_FOREST 1
#define B_DESERT 2
#define B_TAIGA 3
#define B_TUNDRA 4
#define B_OCEAN 5
#define B_BEACH 6
#define B_MOUNTAIN 7
#define B_SWAMP 8
#define B_JUNGLE 9
#define B_SAVANNA 10
#define B_BADLANDS 11
#define B_COUNT 12
#endif
