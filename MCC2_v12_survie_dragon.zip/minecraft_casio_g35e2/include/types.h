#ifndef TYPES_H
#define TYPES_H
#include <stdint.h>
#include "config.h"
typedef int32_t fxp;
typedef struct { int8_t x,y,z; } Vec3i;
typedef struct { fxp x,y,z; } WorldPos;
typedef struct { uint8_t blocks[CHUNK_VOLUME]; int16_t cx,cz; uint8_t used; uint8_t dirty; } Chunk;
typedef struct { uint8_t id; uint8_t count; uint8_t damage; } ItemStack;
/* Creature : position en 8.8 (pieds), vitesses 8.8 par image */
typedef struct { fxp x,y,z; int16_t vx,vy,vz; int16_t hp; uint8_t type,alive,hurt,cd,fuse,dir,timer,gnd; } Mob;
typedef struct { WorldPos pos; int16_t yaw,pitch,vy,hp,hunger,sat; } PlayerState;
#endif
