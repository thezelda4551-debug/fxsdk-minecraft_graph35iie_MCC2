#ifndef INVENTORY_H
#define INVENTORY_H
#include <stdint.h>
#include "types.h"
void inventory_init(void);
ItemStack inventory_slot(int i);
int inventory_selected(void);
void inventory_select_delta(int delta);
int inventory_take(uint8_t id,int n);
int inventory_give(uint8_t id,int n);
int inventory_has(uint8_t id,int n);
int inventory_use_selected(int n);        /* retire n objets de la main */
int inventory_room(uint8_t id,int n);     /* 1 si n objets tiennent encore */
void inventory_damage_tool(int amount);
int inventory_is_tool(uint8_t id);
int inventory_tool_kind(uint8_t id);      /* 0 pioche 1 hache 2 pelle 3 epee, -1 sinon */
int inventory_tool_tier(uint8_t id);      /* 1 bois 2 pierre 3 fer 4 diamant, 0 sinon */
int inventory_attack_damage(void);        /* degats de l'objet en main */
int inventory_food(uint8_t id,int *hunger,int *sat);   /* sat en dixiemes */
const char *inventory_name(uint8_t id);
void inventory_draw(void);
void inventory_screen(void);
void inventory_export(ItemStack *out);
void inventory_import(const ItemStack *in);
#endif
