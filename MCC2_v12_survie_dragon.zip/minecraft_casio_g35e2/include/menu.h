#ifndef MENU_H
#define MENU_H
int menu_run(void);
int menu_pause(void);
#endif
