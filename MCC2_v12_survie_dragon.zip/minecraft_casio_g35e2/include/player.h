#ifndef PLAYER_H
#define PLAYER_H
#include "types.h"
void player_init(void);
void player_update(void);
int player_x(void); int player_y(void); int player_z(void);
void player_pos(int *x,int *y,int *z);             /* pieds, 8.8 */
void player_eye(int *x,int *y,int *z);             /* yeux, 8.8 */
int player_yaw(void); int player_pitch(void);
void player_respawn(void);
void player_dimension_spawn(void);
int player_break_block(void);
int player_place_block(void);
int player_use(void);                               /* F2 : etabli/four/lit, manger, sinon poser */
int player_health(void);
int player_hunger(void);
int player_air(void);
int player_eye_wet(void);
int player_moving(void);
int player_swing(void);
void player_start_swing(void);
int player_falling(void);
void player_damage(int amount);
void player_knock(int vx,int vz);
void player_exhaust(int amount);
void player_export(PlayerState *s);
void player_import(const PlayerState *s);
#endif
