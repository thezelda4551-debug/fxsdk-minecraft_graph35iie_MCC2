#ifndef TEXTURE_H
#define TEXTURE_H
#include <stdint.h>
/* Textures de blocs (monde) et icones d'inventaire, editables en jeu.
   Defaut : textures procedurales 8x8 ; surcharge : bitmap utilisateur sauvegarde. */
void texture_init(void);
int tex_texel(uint8_t id,int u,int v,int face);   /* texture dans le monde : 1 = noir */
int tex_icon_texel(uint8_t id,int u,int v);       /* icone d'inventaire : 1 = noir */
int tex_icon_opaque(uint8_t id);                  /* 1 : dessiner un fond blanc derriere l'icone */
int texture_load(void);
int texture_save(void);
void texture_editor(void);
#endif
