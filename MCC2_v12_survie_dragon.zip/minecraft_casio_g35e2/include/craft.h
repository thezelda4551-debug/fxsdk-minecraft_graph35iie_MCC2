#ifndef CRAFT_H
#define CRAFT_H
void craft_screen(int at_table);   /* at_table=1 : etabli utilise, recettes 3x3 disponibles */
void furnace_screen(void);
int craft_near_table(void);
#endif
