#include "render.h"
#include "world.h"
#include "player.h"
#include "inventory.h"
#include "game.h"
#include "texture.h"
#include "config.h"
#include "trig.h"
#include <gint/display.h>
#include <stdint.h>

/* ------------------------------------------------------------------ */
/*  Rendu voxel monochrome 128x64                                      */
/*  - coordonnees en virgule fixe 8.8 : la vue suit le joueur au pixel  */
/*  - backface culling selon la position des yeux                      */
/*  - tri des blocs du plus loin au plus proche (peintre)              */
/*  - chaque face est texturee en UV (8x8 texels) : plus de blocs vides */
/* ------------------------------------------------------------------ */

static VisibleBlock visible[MAX_VISIBLE_BLOCKS];
static unsigned visible_count;

typedef struct { int x,y; } V2;
typedef struct { int x,y,z; } V3;

static int ex,ey,ez;       /* oeil, 8.8 */
static int cam_s,cam_c;    /* sin/cos du yaw, echelle 256 */
static int cam_pitch;

/* ------------------------- textures -------------------------------- */
static unsigned nz(int u,int v,int id,int f){
    unsigned h=(unsigned)u*374761393u+(unsigned)v*668265263u+(unsigned)id*2246822519u+(unsigned)f*3266489917u;
    h=(h^(h>>13))*1274126177u;
    return (h>>16)&7u;
}
static const uint8_t ore_bits[5][8]={
    {0x00,0x06,0x06,0x00,0x60,0x70,0x20,0x00}, /* charbon  */
    {0x00,0x0C,0x00,0x40,0x00,0x08,0x30,0x00}, /* fer      */
    {0x00,0x60,0x00,0x06,0x04,0x00,0x60,0x00}, /* or       */
    {0x00,0x04,0x40,0x00,0x12,0x04,0x20,0x00}, /* redstone */
    {0x00,0x0C,0x12,0x0C,0x40,0xA0,0x40,0x00}  /* diamant   */
};
static int iabs(int a){return a<0?-a:a;}

int render_texel(uint8_t id,int u,int v,int f){
    unsigned n=nz(u,v,id,f);
    int side=(f!=FACE_YP&&f!=FACE_YN);
    int bd=(u==0||u==7||v==0||v==7);
    switch(id){
    case BLOCK_GRASS:  if(f==FACE_YP)return n<3; if(f==FACE_YN)return n<2; return v<2?(n<5):(n<2);
    case BLOCK_DIRT:   return n<2||(n==2&&((u+v)&1));
    case BLOCK_STONE:  return n<2||(v==3&&u>=1&&u<=3)||(v==6&&u>=5&&u<=6);
    case BLOCK_SAND:   return n<2;
    case BLOCK_WOOD:
        if(!side){int d=iabs(2*u-7),e=iabs(2*v-7);if(e>d)d=e;return d==7||d==3;}
        return ((u+(v>>2))&3)==1||n<1;
    case BLOCK_LEAVES: return n<4;
    case BLOCK_COAL: case BLOCK_IRON: case BLOCK_GOLD: case BLOCK_REDSTONE: case BLOCK_DIAMOND_ORE:
        return n<2||((ore_bits[id==BLOCK_COAL?0:(id==BLOCK_IRON?1:(id==BLOCK_GOLD?2:(id==BLOCK_REDSTONE?3:4)))][v]>>u)&1);
    case BLOCK_TERRACOTTA: return (v&3)==1||(((u+(v>>2)*3)&7)==0);
    case BLOCK_WATER:  return (v&3)==1&&((u+2*(v>>2))&7)<5;
    case BLOCK_PLANKS: return (v&3)==3||u==((v&4)?2:6);
    case BLOCK_COBBLE: return ((u&3)==0&&(v&1))||((v&3)==0&&(u&1))||n<1;
    case BLOCK_GLASS:  return bd||(u==v&&u<4);
    case BLOCK_CRAFTING:
        if(f==FACE_YP)return bd||(u&3)==0||(v&3)==0;
        return bd||v==3||((u==2||u==5)&&v>3);
    case BLOCK_FURNACE:
        return bd||n<1||(side&&u>=2&&u<=5&&v>=3&&v<=5&&(u==2||u==5||v==3));
    case BLOCK_TORCH:
        if(!side)return (u==3||u==4)&&(v==3||v==4);
        return (u==3||u==4)&&v>=1;
    case BLOCK_SNOW:   return f==FACE_YP?(n<1):(n<2);
    case BLOCK_SANDSTONE: return (side&&(v==2||v==5))||n<1;
    case BLOCK_NETHERRACK: return n<3||(n==3&&((u+v)&1));
    case BLOCK_SOUL_SAND:  return n<3||((u==2||u==5)&&(v==2||v==5));
    case BLOCK_GLOWSTONE:  return ((u+v)&3)==0||n<2;
    case BLOCK_LAVA:   return n<3||((u+2*v)&7)==0;
    case BLOCK_QUARTZ: return ((u+v)&7)==3||(side&&v==7);
    case BLOCK_BASALT: return (u&3)==0||n<1;
    case BLOCK_ENDSTONE: return n<2||((u+v)%5)==0;
    case BLOCK_OBSIDIAN: return n<4||(n==4&&((u+v)&1));
    case BLOCK_PORTAL: return ((u+v)&3)==0||((u-v)&7)==0;
    case BLOCK_PURPUR: return (v&3)==0||((u&3)==0&&(v&2));
    case BLOCK_CHORUS: return u==3||u==4||v==3||v==4;
    case BLOCK_MAGMA:  return n<3||((u^v)&3)==3;
    case BLOCK_CACTUS:
        if(!side)return bd||(u==3&&v==3);
        return (u&3)==1||((u&1)&&(v&3)==0);
    case BLOCK_FLOWER:
        return ((u==3||u==4)&&v>=3)||(v<3&&u>=2&&u<=5&&!(v==1&&(u==3||u==4)));
    case BLOCK_BRICKS: return (v&3)==3||((u+((v>>2)<<2))&7)==0;
    case BLOCK_BEDROCK:return n<5;
    case BLOCK_BED:
        if(f==FACE_YP)return bd||(v<3&&u>=2&&u<=5&&((u+v)&1));
        return v>=5||v==2;
    default:           return n<3;
    }
}
/* Blocs transparents : on voit a travers (pas de fond blanc) et ils
   n'occultent pas les faces voisines. */
static int see_through(uint8_t id){
    return id==BLOCK_AIR||id==BLOCK_WATER||id==BLOCK_GLASS||id==BLOCK_TORCH||
           id==BLOCK_FLOWER||id==BLOCK_PORTAL||id==BLOCK_CHORUS;
}

/* --------------------- rasterisation 1 bit ------------------------- */
#define MODE_BLACK (-1)
static const uint8_t dither_rows[4][4]={{0,0,0,0},{1,0,4,0},{5,0,10,0},{5,10,5,10}};
/* niveau de gris par direction de face : haut clair, bas sombre */
static const uint8_t face_dither[6]={2,2,0,3,1,1};

static void span(int y,int xl,int xr,int mode){ /* [xl,xr) */
    if(xl<0)xl=0; if(xr>128)xr=128;
    if(xr<=xl)return;
    if(mode==MODE_BLACK){drect(xl,y,xr-1,y,C_BLACK);return;}
    if(mode==0){drect(xl,y,xr-1,y,C_WHITE);return;}
    for(int x=xl;x<xr;x++)
        dpixel(x,y,((dither_rows[mode][y&3]>>(x&3))&1)?C_BLACK:C_WHITE);
}
/* Remplit un quadrilatere convexe, regle "haut-gauche" : deux quads qui
   partagent une arete ne se recouvrent pas et ne laissent pas de trou. */
static void fill_quad(const V2 *p,int mode){
    int ymin=p[0].y,ymax=p[0].y;
    for(int i=1;i<4;i++){if(p[i].y<ymin)ymin=p[i].y;if(p[i].y>ymax)ymax=p[i].y;}
    int y0=ymin<0?0:ymin,y1=ymax>64?64:ymax;
    for(int y=y0;y<y1;y++){
        int xl=0x7fffffff,xr=-0x7fffffff;
        for(int e=0;e<4;e++){
            V2 s=p[e],t=p[(e+1)&3];
            if(s.y==t.y)continue;
            if(s.y>t.y){V2 w=s;s=t;t=w;}
            if(y<s.y||y>=t.y)continue;
            int x=s.x+((t.x-s.x)*(y-s.y))/(t.y-s.y);
            if(x<xl)xl=x; if(x>xr)xr=x;
        }
        if(xr>xl)span(y,xl,xr,mode);
    }
}
static int outcode(int x,int y){int c=0;if(x<0)c|=1;else if(x>127)c|=2;if(y<0)c|=4;else if(y>63)c|=8;return c;}
static void line_clip(int x0,int y0,int x1,int y1){
    int c0=outcode(x0,y0),c1=outcode(x1,y1);
    for(int it=0;it<8;it++){
        if(!(c0|c1)){dline(x0,y0,x1,y1,C_BLACK);return;}
        if(c0&c1)return;
        int c=c0?c0:c1,x,y;
        if(c&8){x=x0+(x1-x0)*(63-y0)/(y1-y0);y=63;}
        else if(c&4){x=x0+(x1-x0)*(0-y0)/(y1-y0);y=0;}
        else if(c&2){y=y0+(y1-y0)*(127-x0)/(x1-x0);x=127;}
        else{y=y0+(y1-y0)*(0-x0)/(x1-x0);x=0;}
        if(c==c0){x0=x;y0=y;c0=outcode(x,y);}else{x1=x;y1=y;c1=outcode(x,y);}
    }
}

/* --------------------------- projection ---------------------------- */
static void to_cam(int wx,int wy,int wz,V3 *o){
    int rx=wx-ex,ry=wy-ey,rz=wz-ez;
    o->x=(rx*cam_c-rz*cam_s)>>8;
    o->z=(rx*cam_s+rz*cam_c)>>8;
    o->y=ry-(o->z*cam_pitch)/57;
}
static int clampi(int v,int lo,int hi){return v<lo?lo:(v>hi?hi:v);}
static void proj(const V3 *c,V2 *o){
    int z=c->z<NEAR_Z?NEAR_Z:c->z;
    o->x=clampi(64+(c->x*FOCAL)/z,-3000,3000);
    o->y=clampi(32-(c->y*FOCAL)/z,-3000,3000);
}

/* Sommets du cube : index = x + 2*y + 4*z -> on reutilise l'ordre 0..7 de l'ancien code. */
static const int8_t cv[8][3]={{0,0,0},{1,0,0},{1,1,0},{0,1,0},{0,0,1},{1,0,1},{1,1,1},{0,1,1}};
/* q0,q1 = bord bas (u), q3 = au-dessus de q0 (v). */
static const uint8_t cq[6][4]={{1,5,6,2},{4,0,3,7},{3,2,6,7},{0,1,5,4},{5,4,7,6},{0,1,2,3}};

static void draw_face(const V3 *c8,int f,uint8_t id){
    const V3 *q0=&c8[cq[f][0]],*q1=&c8[cq[f][1]],*q3=&c8[cq[f][3]];
    int maxz=q0->z;
    for(int i=1;i<4;i++) if(c8[cq[f][i]].z>maxz)maxz=c8[cq[f][i]].z;
    if(maxz<NEAR_Z)return;                 /* entierement derriere la camera */

    /* emprise ecran des 4 coins */
    V2 pc[4]; int minx=9999,maxx=-9999,miny=9999,maxy=-9999;
    for(int i=0;i<4;i++){
        proj(&c8[cq[f][i]],&pc[i]);
        if(pc[i].x<minx)minx=pc[i].x; if(pc[i].x>maxx)maxx=pc[i].x;
        if(pc[i].y<miny)miny=pc[i].y; if(pc[i].y>maxy)maxy=pc[i].y;
    }
    int allfront=1; for(int i=0;i<4;i++) if(c8[cq[f][i]].z<NEAR_Z)allfront=0;
    if(allfront&&(maxx<0||minx>127||maxy<0||miny>63))return;   /* hors ecran */

    /* treillis grossier : 1x1 (face lointaine) ou 4x4 (perspective correcte) */
    int small=(maxx-minx<=24&&maxy-miny<=24);
    int N=small?1:4, step=8/N;
    V2 co[5][5];
    if(small){
        co[0][0]=pc[0];co[1][0]=pc[1];co[0][1]=pc[3];co[1][1]=pc[2];
    }else{
        for(int j=0;j<=4;j++)for(int i=0;i<=4;i++){
            V3 p;
            p.x=q0->x+(((q1->x-q0->x)*i)>>2)+(((q3->x-q0->x)*j)>>2);
            p.y=q0->y+(((q1->y-q0->y)*i)>>2)+(((q3->y-q0->y)*j)>>2);
            p.z=q0->z+(((q1->z-q0->z)*i)>>2)+(((q3->z-q0->z)*j)>>2);
            proj(&p,&co[i][j]);
        }
    }
    /* treillis fin 9x9 par interpolation bilineaire ecran */
    V2 L[9][9];
    for(int j=0;j<=8;j++){
        int cj=j/step; if(cj>=N)cj=N-1; int fj=j-cj*step;
        for(int i=0;i<=8;i++){
            int ci=i/step; if(ci>=N)ci=N-1; int fi=i-ci*step;
            int w00=(step-fi)*(step-fj),w10=fi*(step-fj),w01=(step-fi)*fj,w11=fi*fj,d=step*step;
            L[i][j].x=(co[ci][cj].x*w00+co[ci+1][cj].x*w10+co[ci][cj+1].x*w01+co[ci+1][cj+1].x*w11)/d;
            L[i][j].y=(co[ci][cj].y*w00+co[ci+1][cj].y*w10+co[ci][cj+1].y*w01+co[ci+1][cj+1].y*w11)/d;
        }
    }
    /* fond : blanc (occulte ce qui est derriere) + degrade selon la direction */
    if(!see_through(id)){
        V2 base[4]={L[0][0],L[8][0],L[8][8],L[0][8]};
        fill_quad(base,face_dither[f]);
    }
    /* texels : un quad noir par texel allume ; si le texel fait < 3 px, un seul point */
    int tiny=(maxx-minx<=10&&maxy-miny<=10);
    for(int tj=0;tj<8;tj++)for(int ti=0;ti<8;ti++){
        if(!tex_texel(id,ti,7-tj,f))continue;
        V2 t[4]={L[ti][tj],L[ti+1][tj],L[ti+1][tj+1],L[ti][tj+1]};
        if(tiny){
            int cx=(t[0].x+t[1].x+t[2].x+t[3].x)>>2,cy=(t[0].y+t[1].y+t[2].y+t[3].y)>>2;
            if((unsigned)cx<128u&&(unsigned)cy<64u)dpixel(cx,cy,C_BLACK);
            continue;
        }
        int tx0=t[0].x,tx1=t[0].x,ty0=t[0].y,ty1=t[0].y;
        for(int k=1;k<4;k++){if(t[k].x<tx0)tx0=t[k].x;if(t[k].x>tx1)tx1=t[k].x;if(t[k].y<ty0)ty0=t[k].y;if(t[k].y>ty1)ty1=t[k].y;}
        if(tx1<0||tx0>127||ty1<0||ty0>63)continue;
        if(tx1-tx0<=2&&ty1-ty0<=2){
            int cx=(t[0].x+t[1].x+t[2].x+t[3].x)>>2,cy=(t[0].y+t[1].y+t[2].y+t[3].y)>>2;
            if((unsigned)cx<128u&&(unsigned)cy<64u)dpixel(cx,cy,C_BLACK);
        }else fill_quad(t,MODE_BLACK);
    }
    /* contour */
    line_clip(L[0][0].x,L[0][0].y,L[8][0].x,L[8][0].y);
    line_clip(L[8][0].x,L[8][0].y,L[8][8].x,L[8][8].y);
    line_clip(L[8][8].x,L[8][8].y,L[0][8].x,L[0][8].y);
    line_clip(L[0][8].x,L[0][8].y,L[0][0].x,L[0][0].y);
}

/* ---------------------------- culling ------------------------------ */
/* Une face est dessinee si (1) son voisin la laisse voir et (2) l'oeil est
   du bon cote du plan de la face (backface culling). */
static int face_open(uint8_t id,int nx,int ny,int nz2){
    if(ny>=WORLD_Y)return 1;
    if(ny<0)return 0;
    if(!world_loaded(nx,nz2))return 0;       /* limite du monde charge : pas de mur factice */
    uint8_t n=world_get(nx,ny,nz2);
    if(n==BLOCK_AIR)return 1;
    if(n==id)return 0;
    return see_through(n);
}
static uint8_t block_mask(int x,int y,int z,uint8_t id){
    uint8_t m=0;
    if(ex>=((x+1)*256)&&face_open(id,x+1,y,z))m|=1<<FACE_XP;
    if(ex<=(x*256)    &&face_open(id,x-1,y,z))m|=1<<FACE_XN;
    if(ey>=((y+1)*256)&&face_open(id,x,y+1,z))m|=1<<FACE_YP;
    if(ey<=(y*256)    &&face_open(id,x,y-1,z))m|=1<<FACE_YN;
    if(ez>=((z+1)*256)&&face_open(id,x,y,z+1))m|=1<<FACE_ZP;
    if(ez<=(z*256)    &&face_open(id,x,y,z-1))m|=1<<FACE_ZN;
    return m;
}

void render_init(void){visible_count=0;}

static void gather(void){
    visible_count=0;
    int ecx=ex>>8,ecz=ez>>8,R=RENDER_RADIUS;
    int r2=(R*256)*(R*256);
    for(int z=ecz-R;z<=ecz+R;z++)for(int x=ecx-R;x<=ecx+R;x++){
        int rx=x*256+128-ex,rz=z*256+128-ez;
        int d2=rx*rx+rz*rz; if(d2>r2)continue;
        int cz=(rx*cam_s+rz*cam_c)>>8, cx=(rx*cam_c-rz*cam_s)>>8;
        if(cz<-300)continue;                              /* derriere */
        if(iabs(cx)>(cz*5)/4+520)continue;                /* hors champ */
        for(int y=0;y<WORLD_Y;y++){
            uint8_t b=world_get(x,y,z); if(!b)continue;
            uint8_t m=block_mask(x,y,z,b); if(!m)continue;
            int ry=y*256+128-ey;
            unsigned key=(unsigned)((d2+ry*ry)>>8); if(key>65535u)key=65535u;
            if(visible_count<MAX_VISIBLE_BLOCKS){
                visible[visible_count++]=(VisibleBlock){(int16_t)x,(int16_t)y,(int16_t)z,b,m,(uint16_t)key};
            }else{                                        /* plein : on garde les plus proches */
                unsigned worst=0;
                for(unsigned i=1;i<visible_count;i++) if(visible[i].key>visible[worst].key)worst=i;
                if(key<visible[worst].key)
                    visible[worst]=(VisibleBlock){(int16_t)x,(int16_t)y,(int16_t)z,b,m,(uint16_t)key};
            }
        }
    }
    /* tri decroissant : le plus loin d'abord (insertion, <=96 elements) */
    for(unsigned i=1;i<visible_count;i++){
        VisibleBlock t=visible[i]; int j=(int)i-1;
        while(j>=0&&visible[j].key<t.key){visible[j+1]=visible[j];j--;}
        visible[j+1]=t;
    }
}

static void rect_clip(int x0,int y0,int x1,int y1,int c){
    if(x0<0)x0=0; if(y0<0)y0=0; if(x1>127)x1=127; if(y1>63)y1=63;
    if(x1>=x0&&y1>=y0)drect(x0,y0,x1,y1,c);
}
static unsigned fcount;
static int occluded(int wx,int wy,int wz){
    for(int k=1;k<8;k++)
        if(world_get((ex+((wx-ex)*k)/8)>>8,(ey+((wy-ey)*k)/8)>>8,(ez+((wz-ez)*k)/8)>>8)!=BLOCK_AIR)return 1;
    return 0;
}
/* Sprite de creature : mx,my,mz = pieds (8.8), hw = demi-largeur, h = hauteur (8.8). */
static void draw_sprite(int mx,int my,int mz,int hw,int h,int type,int hurt,int fuse){
    V3 cf,ct;V2 qf,qt;
    to_cam(mx,my,mz,&cf);to_cam(mx,my+h,mz,&ct);
    if(cf.z<NEAR_Z||cf.z>RENDER_RADIUS*256+256)return;
    if(occluded(mx,my+h/2,mz))return;
    proj(&cf,&qf);proj(&ct,&qt);
    int w=(FOCAL*hw)/cf.z;if(w<1)w=1;
    int x0=qf.x-w,x1=qf.x+w,y0=qt.y,y1=qf.y;
    if(x1<0||x0>127||y1<0||y0>63)return;
    if(type==MOB_CRYSTAL){
        int cx=qf.x,cy=(y0+y1)/2,r=(y1-y0)/2+1;
        line_clip(cx,cy-r,cx+r,cy);line_clip(cx+r,cy,cx,cy+r);line_clip(cx,cy+r,cx-r,cy);line_clip(cx-r,cy,cx,cy-r);
        if(r>2){line_clip(cx,cy-r/2,cx+r/2,cy);line_clip(cx+r/2,cy,cx,cy+r/2);line_clip(cx,cy+r/2,cx-r/2,cy);line_clip(cx-r/2,cy,cx,cy-r/2);}
        return;
    }
    rect_clip(x0,y0,x1,y1,C_BLACK);
    if(hurt||(fuse&&((fuse/3)&1)))return;           /* flash : silhouette pleine */
    int hh=y1-y0;
    switch(type){
    case MOB_ZOMBIE:
        if(w>2){rect_clip(x0+1,y0+1,x0+w/2,y0+hh/4,C_WHITE);rect_clip(x1-w/2,y0+1,x1-1,y0+hh/4,C_WHITE);}
        break;
    case MOB_CREEPER:
        rect_clip(x0+1,y0+1,x1-1,y1-1,C_WHITE);
        if(w>2){
            rect_clip(x0+w/2,y0+hh/6,x0+w-1,y0+hh/3,C_BLACK);rect_clip(x1-w+1,y0+hh/6,x1-w/2,y0+hh/3,C_BLACK);
            rect_clip(qf.x-1,y0+hh/2,qf.x+1,y0+hh*2/3,C_BLACK);
        }
        break;
    case MOB_COW:
        rect_clip(x0+1,y0+1,x1-1,y1-1,C_WHITE);
        if(w>2){rect_clip(x0+2,y0+2,x0+w,y0+hh/2,C_BLACK);rect_clip(qf.x+1,y0+hh/2,x1-2,y1-2,C_BLACK);}
        break;
    default:
        rect_clip(x0+1,y0+1,x1-1,y1-1,C_WHITE);
        if(w>2)rect_clip(qf.x-1,y0+hh/2,qf.x+1,y0+hh/2+1,C_BLACK);
        break;
    }
}
static void draw_mobs(void){
    for(int i=0;i<MAX_MOBS;i++){
        int mx,my,mz,type,hurt,fuse;
        if(!game_mob(i,&mx,&my,&mz,&type,&hurt,&fuse))continue;
        int hw=(type==MOB_COW)?100:(type==MOB_PIG?80:(type==MOB_CRYSTAL?100:70));
        int h=(type==MOB_ZOMBIE)?480:(type==MOB_CREEPER?440:(type==MOB_CRYSTAL?256:230));
        draw_sprite(mx,my,mz,hw,h,type,hurt,fuse);
    }
    int dx,dy,dz,dh;
    if(game_dragon(&dx,&dy,&dz,&dh)){
        V3 c;V2 q;to_cam(dx,dy,dz,&c);
        if(c.z>=NEAR_Z){
            proj(&c,&q);
            int w=(FOCAL*384)/c.z;if(w<2)w=2;
            int flap=(isin((int)fcount*30)*w)/384;
            rect_clip(q.x-w/2,q.y-w/3,q.x+w/2,q.y+w/3,C_BLACK);
            rect_clip(q.x-w/6,q.y-w/2,q.x+w/6,q.y-w/3,C_BLACK);              /* cou/tete */
            rect_clip(q.x-w/10,q.y-w/2,q.x-w/10,q.y-w/2,C_WHITE);
            line_clip(q.x-w/2,q.y,q.x-2*w,q.y-w/2-flap);line_clip(q.x-2*w,q.y-w/2-flap,q.x-w,q.y+w/3);
            line_clip(q.x+w/2,q.y,q.x+2*w,q.y-w/2-flap);line_clip(q.x+2*w,q.y-w/2-flap,q.x+w,q.y+w/3);
            line_clip(q.x,q.y+w/3,q.x,q.y+w);
            if(dh)rect_clip(q.x-w,q.y-w/2,q.x+w,q.y+w/2,C_BLACK);
        }
    }
}
/* Objet tenu en main : icone 8x8 agrandie x2, balancement a la marche et coup de bras. */
static void draw_hand(void){
    ItemStack a=inventory_slot(inventory_selected());
    int bx=100,by=33;
    if(player_moving())by+=(isin((int)fcount*28)*3)>>8,bx+=(icos((int)fcount*28)*2)>>8;
    int sw=player_swing();bx-=sw*3;by-=sw*2;
    if(!a.count){                                   /* poing */
        rect_clip(bx+4,by+8,bx+14,by+17,C_BLACK);rect_clip(bx+5,by+9,bx+13,by+16,C_WHITE);rect_clip(bx+8,by+9,bx+8,by+13,C_BLACK);
        return;
    }
    if(tex_icon_opaque(a.id))rect_clip(bx-1,by-1,bx+16,by+16,C_WHITE);
    for(int v=0;v<8;v++)for(int u=0;u<8;u++)if(tex_icon_texel(a.id,u,v))rect_clip(bx+u*2-1,by+v*2-1,bx+u*2+2,by+v*2+2,C_WHITE);
    for(int v=0;v<8;v++)for(int u=0;u<8;u++)if(tex_icon_texel(a.id,u,v))rect_clip(bx+u*2,by+v*2,bx+u*2+1,by+v*2+1,C_BLACK);
    if(tex_icon_opaque(a.id)){rect_clip(bx-1,by-1,bx+16,by-1,C_BLACK);rect_clip(bx-1,by+16,bx+16,by+16,C_BLACK);rect_clip(bx-1,by-1,bx-1,by+16,C_BLACK);rect_clip(bx+16,by-1,bx+16,by+16,C_BLACK);}
}

void render_frame(void){
    fcount++;
    dclear(C_WHITE);
    player_eye(&ex,&ey,&ez);
    cam_s=isin(player_yaw()); cam_c=icos(player_yaw()); cam_pitch=player_pitch();
    gather();
    for(unsigned i=0;i<visible_count;i++){
        const VisibleBlock *b=&visible[i];
        V3 c8[8];
        for(int v=0;v<8;v++)
            to_cam((b->x+cv[v][0])*256,(b->y+cv[v][1])*256,(b->z+cv[v][2])*256,&c8[v]);
        for(int f=0;f<6;f++) if(b->face_mask&(1<<f)) draw_face(c8,f,b->block);
    }
    draw_mobs();
    if(player_eye_wet())                              /* sous l'eau : voile pointille */
        for(int y=0;y<64;y+=2)for(int x=(y>>1)&1;x<128;x+=4)dpixel(x,y,C_BLACK);
    draw_hand();
    dline(62,32,66,32,C_BLACK);dline(64,30,64,34,C_BLACK);
    inventory_draw();game_draw_hud();
    dupdate();
}
unsigned render_visible_count(void){return visible_count;}
const VisibleBlock*render_visible_list(void){return visible;}
