#include "craft.h"
#include "inventory.h"
#include "player.h"
#include "world.h"
#include "config.h"
#include <gint/display.h>
#include <gint/keyboard.h>
#include <gint/keycodes.h>

/* ------------------------------------------------------------------ */
/*  Recettes : liste d'ingredients (sans grille). Les recettes 3x3     */
/*  demandent un etabli a moins de 4 blocs ou utilise directement.     */
/* ------------------------------------------------------------------ */
typedef struct { uint8_t out,outn,table,n; uint8_t in[3],cnt[3]; } Recipe;
#define TOOLS(P,A,S,W,M) \
 {P,1,1,2,{M,ITEM_STICK},{3,2}},{A,1,1,2,{M,ITEM_STICK},{3,2}},\
 {S,1,1,2,{M,ITEM_STICK},{1,2}},{W,1,1,2,{M,ITEM_STICK},{2,1}}
static const Recipe R[]={
 {BLOCK_PLANKS,4,0,1,{BLOCK_WOOD},{1}},
 {ITEM_STICK,4,0,1,{BLOCK_PLANKS},{2}},
 {BLOCK_CRAFTING,1,0,1,{BLOCK_PLANKS},{4}},
 {BLOCK_TORCH,4,0,2,{ITEM_COAL,ITEM_STICK},{1,1}},
 {BLOCK_FURNACE,1,1,1,{BLOCK_COBBLE},{8}},
 {BLOCK_SANDSTONE,1,0,1,{BLOCK_SAND},{4}},
 {BLOCK_BRICKS,2,1,1,{BLOCK_NETHERRACK},{4}},
 TOOLS(ITEM_PICKAXE_WOOD,ITEM_AXE_WOOD,ITEM_SHOVEL_WOOD,ITEM_SWORD_WOOD,BLOCK_PLANKS),
 TOOLS(ITEM_PICKAXE_STONE,ITEM_AXE_STONE,ITEM_SHOVEL_STONE,ITEM_SWORD_STONE,BLOCK_COBBLE),
 TOOLS(ITEM_PICKAXE_IRON,ITEM_AXE_IRON,ITEM_SHOVEL_IRON,ITEM_SWORD_IRON,ITEM_IRON_INGOT),
 TOOLS(ITEM_PICKAXE_DIAMOND,ITEM_AXE_DIAMOND,ITEM_SHOVEL_DIAMOND,ITEM_SWORD_DIAMOND,ITEM_DIAMOND),
};
#define NR ((int)(sizeof R/sizeof R[0]))

int craft_near_table(void){
    int px=player_x(),py=player_y(),pz=player_z();
    for(int z=pz-4;z<=pz+4;z++)for(int x=px-4;x<=px+4;x++)for(int y=py-2;y<=py+3;y++)
        if(world_get(x,y,z)==BLOCK_CRAFTING)return 1;
    return 0;
}
static int has_all(const Recipe *r){
    for(int i=0;i<r->n;i++)if(!inventory_has(r->in[i],r->cnt[i]))return 0;
    return 1;
}
static int do_craft(const Recipe *r){
    ItemStack snap[INVENTORY_SLOTS];
    inventory_export(snap);
    for(int i=0;i<r->n;i++)inventory_take(r->in[i],r->cnt[i]);
    if(!inventory_give(r->out,r->outn)){inventory_import(snap);return 0;}   /* inventaire plein : rien n'est consomme */
    return 1;
}
static int put_int(char *s,int n){int l=n>=10?2:1;if(n>=10)s[0]=(char)('0'+n/10);s[l-1]=(char)('0'+n%10);return l;}
static void ingredients(const Recipe *r,char *s){
    int p=0;
    for(int i=0;i<r->n;i++){
        if(i)s[p++]=',';
        p+=put_int(s+p,r->cnt[i]);s[p++]=' ';
        const char *nm=inventory_name(r->in[i]);
        for(int k=0;nm[k]&&k<8;k++)s[p++]=nm[k];
    }
    s[p]=0;
}
void craft_screen(int at_table){
    int sel=0,top=0,msg=0;
    for(;;){
        int table=at_table||craft_near_table();
        dclear(C_WHITE);
        dtext(1,0,C_BLACK,table?"ETABLI 3X3":"FABRICATION 2X2");
        for(int row=0;row<5;row++){
            int i=top+row;if(i>=NR)break;
            const Recipe *r=&R[i];
            int y=9+row*7,ok=has_all(r)&&(!r->table||table);
            if(i==sel)drect(0,y-1,127,y+6,C_BLACK);
            int fg=(i==sel)?C_WHITE:C_BLACK;
            if(ok)drect(2,y+1,4,y+3,fg);else dpixel(3,y+2,fg);
            dtext(8,y,fg,inventory_name(r->out));
            if(r->outn>1){char n[4]={'x',(char)('0'+r->outn),0,0};dtext(96,y,fg,n);}
            if(r->table)dtext(118,y,fg,"T");
        }
        {char buf[40];ingredients(&R[sel],buf);dtext(1,46,C_BLACK,buf);}
        dtext(1,57,C_BLACK,msg==1?"INGREDIENTS MANQUANTS":msg==2?"INVENTAIRE PLEIN":msg==3?"IL FAUT UN ETABLI":"EXE:FABRIQUER EXIT:RETOUR");
        dupdate();
        key_event_t ev;do{ev=getkey();}while(ev.type!=KEYEV_DOWN);
        if(ev.key==KEY_EXIT||ev.key==KEY_F5)return;
        if(ev.key==KEY_UP){sel=(sel+NR-1)%NR;msg=0;}
        if(ev.key==KEY_DOWN){sel=(sel+1)%NR;msg=0;}
        if(sel<top)top=sel;
        if(sel>=top+5)top=sel-4;
        if(sel==NR-1&&top<NR-5)top=NR-5;
        if(sel==0)top=0;
        if(ev.key==KEY_EXE){
            const Recipe *r=&R[sel];
            if(r->table&&!table)msg=3;
            else if(!has_all(r))msg=1;
            else msg=do_craft(r)?0:2;
        }
    }
}

/* ------------------------------ four ------------------------------- */
typedef struct { uint8_t in,out; } Smelt;
static const Smelt S[]={
 {BLOCK_IRON,ITEM_IRON_INGOT},{BLOCK_GOLD,ITEM_GOLD_INGOT},{BLOCK_SAND,BLOCK_GLASS},
 {BLOCK_COBBLE,BLOCK_STONE},{ITEM_RAW_MEAT,ITEM_COOKED_MEAT},{BLOCK_WOOD,ITEM_COAL},{BLOCK_NETHERRACK,BLOCK_BRICKS},
};
#define NS ((int)(sizeof S/sizeof S[0]))
static int fuel_left;   /* nombre de cuissons restantes sur le combustible en cours */
static int refuel(void){
    if(fuel_left>0)return 1;
    static const struct{uint8_t id;uint8_t burns;}F[3]={{ITEM_COAL,8},{BLOCK_PLANKS,1},{BLOCK_WOOD,3}};
    for(int i=0;i<3;i++)if(inventory_has(F[i].id,1)){inventory_take(F[i].id,1);fuel_left=F[i].burns;return 1;}
    return 0;
}
/* 1 = cuit, 0 = pas d'ingredient, -1 = pas de combustible, -2 = inventaire plein */
static int smelt_one(const Smelt *s){
    if(!inventory_has(s->in,1))return 0;
    if(!refuel())return -1;
    ItemStack snap[INVENTORY_SLOTS];
    inventory_export(snap);
    inventory_take(s->in,1);
    if(!inventory_give(s->out,1)){inventory_import(snap);return -2;}
    fuel_left--;
    return 1;
}
void furnace_screen(void){
    int sel=0,msg=0;
    for(;;){
        dclear(C_WHITE);
        dtext(1,0,C_BLACK,"FOUR");
        {char b[12]="CUISSONS:";b[9]=(char)('0'+(fuel_left>9?9:fuel_left));b[10]=0;dtext(70,0,C_BLACK,b);}
        for(int i=0;i<NS;i++){
            int y=9+i*7,fg=(i==sel)?C_WHITE:C_BLACK;
            if(i==sel)drect(0,y-1,127,y+6,C_BLACK);
            dtext(2,y,fg,inventory_name(S[i].in));
            dtext(66,y,fg,">");
            dtext(72,y,fg,inventory_name(S[i].out));
            if(!inventory_has(S[i].in,1))dline(2,y+3,60,y+3,fg);   /* barre : ingredient absent */
        }
        dtext(1,57,C_BLACK,msg==1?"PAS DE COMBUSTIBLE":msg==2?"RIEN A CUIRE":msg==3?"INVENTAIRE PLEIN":"EXE:1 F1:TOUT  EXIT");
        dupdate();
        key_event_t ev;do{ev=getkey();}while(ev.type!=KEYEV_DOWN);
        if(ev.key==KEY_EXIT||ev.key==KEY_F5)return;
        if(ev.key==KEY_UP){sel=(sel+NS-1)%NS;msg=0;}
        if(ev.key==KEY_DOWN){sel=(sel+1)%NS;msg=0;}
        if(ev.key==KEY_EXE||ev.key==KEY_F1){
            int n=(ev.key==KEY_F1)?64:1,done=0,r=0;
            while(n--&&(r=smelt_one(&S[sel]))==1)done++;
            msg=done?0:(r==-1?1:(r==-2?3:2));
        }
    }
}
