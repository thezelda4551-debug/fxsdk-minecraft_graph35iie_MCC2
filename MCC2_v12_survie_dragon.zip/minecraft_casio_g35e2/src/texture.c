#include "texture.h"
#include "render.h"
#include "inventory.h"
#include "config.h"
#include <gint/display.h>
#include <gint/keyboard.h>
#include <gint/keycodes.h>
#include <gint/bfile.h>
#include <string.h>

/* Surcharges utilisateur : bit u de la ligne v = pixel (u,v), 1 = noir. */
static uint8_t user_tex[LAST_BLOCK+1][8];
static uint8_t user_icon[NUM_IDS][8];
static uint8_t flags[NUM_IDS];           /* bit0 : texture de bloc, bit1 : icone */
#define F_TEX 1
#define F_ICON 2

/* ---- icones d'objets : 8 lignes de 8 caracteres, X = noir ---- */
static const char *const item_art[][8]={
 /*40 baton*/ {"........",".......X","......X.",".....X..","....X...","...X....","..X.....",".X......"},
 /*41 charbon*/ {"........","..XXXX..",".XX.XXX.",".XXXX.X.",".X.XXXX.",".XXX.XX.","..XXXX..","........"},
 /*42 lingot fer*/ {"........","........","..XXXXXX",".X.....X","XXXXXXX.","X.....X.","XXXXXXX.","........"},
 /*43 lingot or*/ {"........","........","..XXXXXX",".XXXXXXX","XXXXXXXX","XXXXXXX.","XXXXXXX.","........"},
 /*44 diamant*/ {"........","..XXXX..",".X.XX.X.","XXXXXXXX",".X.XX.X.","..X..X..","...XX...","........"},
 /*45 pomme*/ {"....X...","...X....",".XXXXXX.","XX.XXXXX","XXXXXXXX","XXXXXXXX",".XXXXXX.","..X..X.."},
 /*46 viande crue*/ {"........","..XXXX..",".X....X.","X.XX..XX","X..XX..X","X.....X.",".XXXXXX.","........"},
 /*47 steak*/ {"........","..XXXX..",".XXXXXXX","XXX.XXXX","XXXXXXXX","XX.XXXX.",".XXXXXX.","........"},
 /*48 chair pourrie*/ {"........",".X.XXX..","XXX.XXX.",".XXXX.XX","XX.XXXX.",".XXX.XX.","..XXXX..","........"},
};
/* Outils : S = manche, H = tete (remplie selon le materiau). */
static const char *const tool_art[4][8]={
 /*pioche*/ {"..HHHH..",".H....H.","H..S...H","...S....","..S.....",".S......","S.......","........"},
 /*hache*/  {"...HH...","..HHHH..","..HHSH..","...HS...","...S....","..S.....",".S......","S......."},
 /*pelle*/  {"......HH",".....HHH","....SHH.","...S....","..S.....",".S......","S.......","........"},
 /*epee*/   {"......HH",".....HHH","....HHH.","...HHH..","S.HHH...",".SHH....","..S.....",".S.S...."},
};
static int item_bit(uint8_t id,int u,int v){
    if(id>=ITEM_STICK&&id<=ITEM_ROTTEN){
        return item_art[id-ITEM_STICK][v][u]=='X';
    }
    int kind=-1,tier=1;
    if(id>=ITEM_PICKAXE_WOOD&&id<=ITEM_SWORD_IRON){kind=(id-ITEM_PICKAXE_WOOD)/3;tier=(id-ITEM_PICKAXE_WOOD)%3+1;}
    else if(id>=ITEM_PICKAXE_DIAMOND&&id<=ITEM_SWORD_DIAMOND){kind=id-ITEM_PICKAXE_DIAMOND;tier=4;}
    if(kind<0)return (u>=2&&u<=5&&v>=2&&v<=5);
    char c=tool_art[kind][v][u];
    if(c=='S')return 1;
    if(c!='H')return 0;
    switch(tier){
    case 1: return ((u+v)&1)==0 || u==0 || v==0;      /* bois : damier */
    case 2: return !(u==4&&v==2) ;                    /* pierre : plein, un trou */
    case 3: return 1;                                 /* fer : plein */
    default: return !(((u+v)&3)==0);                  /* diamant : facettes */
    }
}
static int is_block(uint8_t id){return id>=1&&id<=LAST_BLOCK;}

int tex_texel(uint8_t id,int u,int v,int face){
    if(is_block(id)&&(flags[id]&F_TEX))return (user_tex[id][v]>>u)&1;
    return render_texel(id,u,v,face);
}
int tex_icon_texel(uint8_t id,int u,int v){
    if(id<NUM_IDS&&(flags[id]&F_ICON))return (user_icon[id][v]>>u)&1;
    if(is_block(id)){
        if(id==BLOCK_TORCH)return ((u==3||u==4)&&v>=1&&v<=7);
        return tex_texel(id,u,v,4);
    }
    return item_bit(id,u,v);
}
int tex_icon_opaque(uint8_t id){
    if(id<NUM_IDS&&(flags[id]&F_ICON))return 0;
    return is_block(id)&&id!=BLOCK_TORCH&&id!=BLOCK_FLOWER&&id!=BLOCK_CHORUS;
}

/* ---- sauvegarde ---- */
static uint16_t const tex_path[]={'\\','\\','f','l','s','0','\\','M','C','C','2','T','E','X','.','s','a','v',0};
#define TEX_MAGIC 0x4D544301u
void texture_init(void){memset(user_tex,0,sizeof user_tex);memset(user_icon,0,sizeof user_icon);memset(flags,0,sizeof flags);}
int texture_save(void){
    uint32_t magic=TEX_MAGIC;
    int size=(int)(sizeof magic+sizeof flags+sizeof user_tex+sizeof user_icon);
    BFile_Remove(tex_path);
    if(BFile_Create(tex_path,BFile_File,&size)<0)return 0;
    int h=BFile_Open(tex_path,BFile_WriteOnly);
    if(h<0)return 0;
    int ok=BFile_Write(h,&magic,sizeof magic)>=0&&BFile_Write(h,flags,sizeof flags)>=0
        &&BFile_Write(h,user_tex,sizeof user_tex)>=0&&BFile_Write(h,user_icon,sizeof user_icon)>=0;
    BFile_Close(h);
    return ok;
}
int texture_load(void){
    int h=BFile_Open(tex_path,BFile_ReadOnly);
    if(h<0)return 0;
    uint32_t magic=0;
    int ok=BFile_Read(h,&magic,sizeof magic,-1)>=0&&magic==TEX_MAGIC
        &&BFile_Read(h,flags,sizeof flags,-1)>=0&&BFile_Read(h,user_tex,sizeof user_tex,-1)>=0
        &&BFile_Read(h,user_icon,sizeof user_icon,-1)>=0;
    BFile_Close(h);
    if(!ok)texture_init();
    return ok;
}

/* ---- editeur ---- */
static void load_buf(int id,int mode,uint8_t *buf){
    for(int v=0;v<8;v++){
        uint8_t row=0;
        for(int u=0;u<8;u++){
            int on=(mode==0)?tex_texel((uint8_t)id,u,v,4):tex_icon_texel((uint8_t)id,u,v);
            if(on)row|=(uint8_t)(1<<u);
        }
        buf[v]=row;
    }
}
static void commit(int id,int mode,const uint8_t *buf){
    if(mode==0){memcpy(user_tex[id],buf,8);flags[id]|=F_TEX;}
    else{memcpy(user_icon[id],buf,8);flags[id]|=F_ICON;}
}
void texture_editor(void){
    int id=1,mode=0,cx=0,cy=0;
    uint8_t buf[8];
    load_buf(id,mode,buf);
    for(;;){
        dclear(C_WHITE);
        dtext(2,0,C_BLACK,"TEXTURES");
        dtext(60,0,C_BLACK,mode==0?"BLOC":"ICONE");
        /* grille 8x8 agrandie x5 */
        for(int v=0;v<8;v++)for(int u=0;u<8;u++){
            int x=3+u*5,y=9+v*5;
            if((buf[v]>>u)&1)drect(x,y,x+4,y+4,C_BLACK);
            else{dpixel(x,y,C_BLACK);dpixel(x+4,y,C_BLACK);dpixel(x,y+4,C_BLACK);dpixel(x+4,y+4,C_BLACK);}
        }
        {int x=3+cx*5,y=9+cy*5;
         drect(x-1,y-1,x+5,y-1,C_BLACK);drect(x-1,y+5,x+5,y+5,C_BLACK);
         drect(x-1,y-1,x-1,y+5,C_BLACK);drect(x+5,y-1,x+5,y+5,C_BLACK);
         dpixel(x+2,y+2,((buf[cy]>>cx)&1)?C_WHITE:C_BLACK);}
        /* apercus 1x et 2x */
        for(int v=0;v<8;v++)for(int u=0;u<8;u++){
            if((buf[v]>>u)&1){dpixel(54+u,12+v,C_BLACK);drect(66+u*2,12+v*2,67+u*2,13+v*2,C_BLACK);}
        }
        drect(53,11,62,20,C_BLACK);                        /* cadre 1x (contour) */
        for(int v=0;v<8;v++)for(int u=0;u<8;u++)if((buf[v]>>u)&1)dpixel(54+u,12+v,C_BLACK);
        {int idl=id/10,idu=id%10;char s[4]={(char)('0'+idl),(char)('0'+idu),0,0};dtext(54,24,C_BLACK,s);}
        dtext(54,32,C_BLACK,inventory_name((uint8_t)id));
        dtext(54,40,C_BLACK,(flags[id]&((mode==0)?F_TEX:F_ICON))?"PERSO":"DEFAUT");
        dtext(1,50,C_BLACK,"EXE:PIXEL F1:VIDE F2:INV");
        dtext(1,57,C_BLACK,"F3/4:ID F5:MODE EXIT:OK");
        dupdate();
        key_event_t ev;do{ev=getkey();}while(ev.type!=KEYEV_DOWN);
        if(ev.key==KEY_EXIT){texture_save();return;}
        if(ev.key==KEY_LEFT)cx=(cx+7)&7;
        if(ev.key==KEY_RIGHT)cx=(cx+1)&7;
        if(ev.key==KEY_UP)cy=(cy+7)&7;
        if(ev.key==KEY_DOWN)cy=(cy+1)&7;
        if(ev.key==KEY_EXE){buf[cy]^=(uint8_t)(1<<cx);commit(id,mode,buf);}
        if(ev.key==KEY_F1){
            if(ev.shift){                                   /* SHIFT+F1 : retour au defaut */
                flags[id]&=(uint8_t)~((mode==0)?F_TEX:F_ICON);load_buf(id,mode,buf);
            }else{memset(buf,0,8);commit(id,mode,buf);}
        }
        if(ev.key==KEY_F2){for(int v=0;v<8;v++)buf[v]=(uint8_t)~buf[v];commit(id,mode,buf);}
        int nid=id;
        if(ev.key==KEY_F3)nid=(id<=1)?LAST_ID:id-1;
        if(ev.key==KEY_F4)nid=(id>=LAST_ID)?1:id+1;
        while((nid>LAST_BLOCK&&nid<ITEM_STICK)||(nid>ITEM_ROTTEN&&nid<ITEM_PICKAXE_WOOD)){
            nid=(ev.key==KEY_F3)?nid-1:nid+1;
        }
        if(nid!=id){id=nid;if(!is_block((uint8_t)id))mode=1;load_buf(id,mode,buf);}
        if(ev.key==KEY_F5&&is_block((uint8_t)id)){mode^=1;load_buf(id,mode,buf);}
    }
}
