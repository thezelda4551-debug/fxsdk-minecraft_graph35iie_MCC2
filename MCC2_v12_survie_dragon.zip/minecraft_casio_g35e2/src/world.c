#include "world.h"
#include "config.h"
#include <string.h>
#include <gint/bfile.h>

/* ------------------------------------------------------------------ */
/*  Monde procedural : tout est deterministe a partir de la graine.    */
/*  Seules les modifications du joueur sont stockees (liste d'edits),  */
/*  ce qui rend la sauvegarde minuscule et evite de perdre les blocs   */
/*  poses/casses quand un chunk sort de la fenetre active.             */
/* ------------------------------------------------------------------ */

static Chunk chunks[ACTIVE_CHUNKS];
static uint32_t seed=0x13579BDFu;
static uint8_t dimension;
typedef struct { int16_t x,z; uint8_t y,id,dim,pad; } Edit;   /* 8 octets */
static Edit edits[MAX_EDITS];
static int n_edits,edit_next;

static int floor_div8(int v){return v>>3;}
static int mod8(int v){return v&7;}
static int slot_for(int cx,int cz){for(int i=0;i<ACTIVE_CHUNKS;i++)if(chunks[i].used&&chunks[i].cx==cx&&chunks[i].cz==cz)return i;return -1;}
static int fdiv(int a,int b){int q=a/b;if((a%b)!=0&&((a<0)!=(b<0)))q--;return q;}

static uint32_t hsh(int x,int y,int z,uint32_t salt){
    uint32_t h=seed+salt*2654435761u;
    h^=(uint32_t)x*374761393u; h=((h<<13)|(h>>19))*1274126177u;
    h^=(uint32_t)z*668265263u; h=(h^(h>>15))*2246822519u;
    h^=(uint32_t)y*3266489917u; h^=h>>16; h*=2246822519u; h^=h>>13;
    return h;
}
/* bruit de valeur 2D lisse, resultat 0..255, cellule = 1<<sh blocs */
static int vn2(int x,int z,int sh,uint32_t salt){
    int gx=x>>sh,gz=z>>sh,m=(1<<sh)-1;
    int tx=(x&m)<<(8-sh),tz=(z&m)<<(8-sh);
    tx=(tx*tx*(768-2*tx))>>16; tz=(tz*tz*(768-2*tz))>>16;
    int a=(int)(hsh(gx,0,gz,salt)&255),b=(int)(hsh(gx+1,0,gz,salt)&255);
    int c=(int)(hsh(gx,0,gz+1,salt)&255),d=(int)(hsh(gx+1,0,gz+1,salt)&255);
    int top=a+(((b-a)*tx)>>8),bot=c+(((d-c)*tx)>>8);
    return top+(((bot-top)*tz)>>8);
}
/* bruit 3D (grottes) : cellule 4x2x4 */
static int vn3(int x,int y,int z,uint32_t salt){
    int gx=x>>2,gy=y>>1,gz=z>>2,fx=(x&3)<<6,fy=(y&1)<<7,fz=(z&3)<<6;
    int v[8];
    for(int i=0;i<8;i++)v[i]=(int)(hsh(gx+(i&1),gy+((i>>1)&1),gz+((i>>2)&1),salt)&255);
    int x00=v[0]+(((v[1]-v[0])*fx)>>8),x10=v[2]+(((v[3]-v[2])*fx)>>8);
    int x01=v[4]+(((v[5]-v[4])*fx)>>8),x11=v[6]+(((v[7]-v[6])*fx)>>8);
    int y0=x00+(((x10-x00)*fy)>>8),y1=x01+(((x11-x01)*fy)>>8);
    return y0+(((y1-y0)*fz)>>8);
}

/* ---------------------------- biomes -------------------------------- */
static void column(int wx,int wz,int *ph,int *pb){
    int e=vn2(wx,wz,4,1);
    int h=1+((e*8)>>8);
    int d=vn2(wx,wz,2,2);
    if(h>SEA_LEVEL+1){if(d>200)h++;else if(d<55)h--;}
    if(h>WORLD_Y-2)h=WORLD_Y-2;
    if(h<1)h=1;
    int t=vn2(wx,wz,5,3),m=vn2(wx,wz,5,4),b;
    if(h<SEA_LEVEL)b=B_OCEAN;
    else if(h==SEA_LEVEL&&vn2(wx,wz,3,6)<150)b=(t<85)?B_TUNDRA:B_BEACH;
    else if(h>=7)b=B_MOUNTAIN;
    else if(t<100)b=(m>115)?B_TAIGA:B_TUNDRA;
    else if(t>150){
        if(m<115)b=(t>175)?B_BADLANDS:B_DESERT;
        else if(m<140)b=B_SAVANNA;
        else b=B_JUNGLE;
    }else{
        if(m>160)b=B_SWAMP; else if(m>125)b=B_FOREST; else b=B_PLAINS;
    }
    *ph=h;*pb=b;
}
int world_biome(int x,int z){int h,b;column(x,z,&h,&b);return b;}

/* --------------------------- structures ----------------------------- */
enum { S_NONE=0,S_HOUSE,S_WELL,S_PYRAMID,S_IGLOO,S_TEMPLE,S_RPORTAL,S_FORTRESS };
static const uint8_t SW[8]={0,5,3,9,5,7,4,9};
static const uint8_t SD[8]={0,5,3,9,5,7,3,5};
typedef struct { int16_t rx,rz; uint8_t ok,type,base,var; int16_t ox,oz; } Region;
static Region rc[4];
static int nether_h(int wx,int wz){return 1+((vn2(wx,wz,3,5)*4)>>8);}
static const Region *get_region(int rx,int rz){
    Region *r=&rc[(rx&1)|((rz&1)<<1)];
    if(r->ok&&r->rx==rx&&r->rz==rz)return r;
    r->ok=1;r->rx=(int16_t)rx;r->rz=(int16_t)rz;r->type=0;
    uint32_t h=hsh(rx,0,rz,31);
    if(dimension==0){
        if(h%4u)return r;
        int ox=rx*16+2+(int)((h>>8)&3),oz=rz*16+2+(int)((h>>12)&3),th,tb;
        column(ox,oz,&th,&tb);
        r->ox=(int16_t)ox;r->oz=(int16_t)oz;r->base=(uint8_t)th;r->var=(uint8_t)((h>>16)&255);
        if(th<=SEA_LEVEL||th>5)return r;
        int v=r->var;
        switch(tb){
        case B_DESERT: r->type=(v&1)?S_PYRAMID:S_WELL; break;
        case B_PLAINS: r->type=(v%7==0)?S_RPORTAL:((v%3==0)?S_WELL:S_HOUSE); break;
        case B_FOREST: r->type=(v%5==0)?S_RPORTAL:S_HOUSE; break;
        case B_SAVANNA: r->type=S_HOUSE; break;
        case B_TAIGA: r->type=(v&1)?S_HOUSE:S_IGLOO; break;
        case B_TUNDRA: r->type=S_IGLOO; break;
        case B_JUNGLE: r->type=S_TEMPLE; break;
        case B_MOUNTAIN: r->type=S_RPORTAL; break;
        case B_SWAMP: r->type=S_HOUSE; break;
        default: break;
        }
    }else if(dimension==1){
        if(h%3u)return r;
        int ox=rx*16+2+(int)((h>>8)&3),oz=rz*16+2+(int)((h>>12)&3);
        r->ox=(int16_t)ox;r->oz=(int16_t)oz;r->var=(uint8_t)((h>>16)&255);
        if(((h>>20)&3)==0){r->type=S_RPORTAL;r->base=(uint8_t)nether_h(ox,oz);}
        else{r->type=S_FORTRESS;r->base=5;}
    }
    return r;
}
/* Bloc d'une structure en (dx,dy,dz) relatif a l'origine ; dy=0 remplace le sol.
   -1 = rien (on garde le terrain), sinon id (BLOCK_AIR = on creuse). */
static int sblock(int t,int dx,int dy,int dz,int var){
    switch(t){
    case S_HOUSE:{
        int edge=(dx==0||dx==4||dz==0||dz==4);
        int corner=((dx==0||dx==4)&&(dz==0||dz==4));
        if(dy==0)return BLOCK_PLANKS;
        if(dy==1||dy==2){
            if(!edge){
                if(dy==1){
                    if(dx==3&&dz==3)return BLOCK_BED;
                    if(dx==1&&dz==3)return BLOCK_CRAFTING;
                    if(dx==3&&dz==1)return BLOCK_FURNACE;
                    if(dx==1&&dz==1)return BLOCK_TORCH;
                }
                return BLOCK_AIR;
            }
            if(dx==2&&dz==0)return BLOCK_AIR;
            if(dy==2&&(((dx==0||dx==4)&&dz==2)||(dz==4&&dx==2)))return BLOCK_GLASS;
            return corner?BLOCK_WOOD:BLOCK_PLANKS;
        }
        if(dy==3)return BLOCK_PLANKS;
        return -1;}
    case S_WELL:{
        int c=(dx==1&&dz==1),corner=(dx!=1&&dz!=1);
        if(dy==0)return c?BLOCK_WATER:BLOCK_COBBLE;
        if(dy==1||dy==2)return corner?BLOCK_WOOD:BLOCK_AIR;
        if(dy==3)return BLOCK_PLANKS;
        return -1;}
    case S_PYRAMID:{
        if(dy==0)return BLOCK_SANDSTONE;
        int k=dy-1;
        if(k<0||k>3)return -1;
        if(dx<k||dx>8-k||dz<k||dz>8-k)return -1;
        if(dy<=2&&dx>=2&&dx<=6&&dz>=2&&dz<=6)return (dy==1&&dx==4&&dz==4)?BLOCK_GOLD:BLOCK_AIR;
        if(dy<=2&&dx==4&&dz<2)return BLOCK_AIR;
        return (dy==4&&dx==4&&dz==4)?BLOCK_TERRACOTTA:BLOCK_SANDSTONE;}
    case S_IGLOO:{
        int edge=(dx==0||dx==4||dz==0||dz==4);
        if(dy==0)return BLOCK_SNOW;
        if(dy==1||dy==2){
            if(edge)return (dx==2&&dz==0)?BLOCK_AIR:BLOCK_SNOW;
            return (dy==1&&dx==2&&dz==2)?BLOCK_TORCH:BLOCK_AIR;
        }
        if(dy==3)return BLOCK_SNOW;
        return -1;}
    case S_TEMPLE:{
        int edge=(dx==0||dx==6||dz==0||dz==6);
        if(dy==0)return BLOCK_COBBLE;
        if(dy==1||dy==2){
            if(edge)return (dx==3&&dz==0)?BLOCK_AIR:BLOCK_COBBLE;
            return (dy==1&&dx==3&&dz==3)?BLOCK_GOLD:BLOCK_AIR;
        }
        if(dy==3)return BLOCK_COBBLE;
        if(dy==4)return (dx>=2&&dx<=4&&dz>=2&&dz<=4)?BLOCK_COBBLE:-1;
        return -1;}
    case S_RPORTAL:
        if(dz==1){
            if(dx==0||dx==3){
                if(dy>4)return -1;
                if((var&1)&&dx==3&&dy==4)return -1;
                return BLOCK_OBSIDIAN;
            }
            if(dy==0||dy==4){if((var&2)&&dx==1&&dy==4)return -1;return BLOCK_OBSIDIAN;}
            if(dy>=1&&dy<=3)return BLOCK_PORTAL;
            return -1;
        }
        if(dy==0&&((dx+dz+var)%3)!=0)return BLOCK_NETHERRACK;
        return -1;
    case S_FORTRESS:
        if(dz==0||dz==4)return -1;
        if(dy==0)return BLOCK_BRICKS;
        if(dy==1)return (dz==1||dz==3)?BLOCK_BRICKS:BLOCK_AIR;
        if(dy==2)return ((dz==1||dz==3)&&(dx&1)==0)?BLOCK_BRICKS:BLOCK_AIR;
        if(dy==3)return (dx%4==0&&(dz==1||dz==3))?BLOCK_BRICKS:-1;
        return -1;
    }
    return -1;
}

/* ---------------------------- generation ---------------------------- */
static void setc(Chunk *c,int x,int y,int z,uint8_t id){if(x>=0&&x<8&&y>=0&&y<WORLD_Y&&z>=0&&z<8)c->blocks[y*64+z*8+x]=id;}
static void setair(Chunk *c,int x,int y,int z,uint8_t id){if(x>=0&&x<8&&y>=0&&y<WORLD_Y&&z>=0&&z<8&&c->blocks[y*64+z*8+x]==0)c->blocks[y*64+z*8+x]=id;}

/* Arbres sur une grille de pas 3 : chaque colonne depend d'un seul tronc candidat,
   donc aucun arbre n'est coupe par une frontiere de chunk. */
static void apply_tree(Chunk *c,int x,int z,int wx,int wz,int h,int b){
    int tx=fdiv(wx+1,3)*3,tz=fdiv(wz+1,3)*3;
    unsigned tr=hsh(tx,0,tz,21)&1023u;
    if(tr>=460u)return;
    int th,tb;
    if(tx==wx&&tz==wz){th=h;tb=b;}else column(tx,tz,&th,&tb);
    unsigned thr;
    switch(tb){case B_FOREST:thr=300;break;case B_JUNGLE:thr=460;break;case B_TAIGA:thr=220;break;
               case B_SWAMP:thr=100;break;case B_SAVANNA:thr=60;break;case B_PLAINS:thr=45;break;default:return;}
    if(tr>=thr||th<=SEA_LEVEL)return;
    int tt=(tb==B_JUNGLE)?4:3;
    if(th+tt+1>WORLD_Y-1)return;
    int dx=wx-tx,dz=wz-tz;
    if(dx==0&&dz==0)for(int y=th+1;y<=th+tt;y++)setair(c,x,y,z,BLOCK_WOOD);
    else{
        setair(c,x,th+tt-1,z,BLOCK_LEAVES);
        if(!((hsh(tx,0,tz,22)&1)&&dx!=0&&dz!=0))setair(c,x,th+tt,z,BLOCK_LEAVES);
    }
    if(dx==0||dz==0)setair(c,x,th+tt+1,z,BLOCK_LEAVES);
}

static void apply_structure(Chunk *c,int x,int z,int wx,int wz,int colh){
    const Region *r=get_region(wx>>4,wz>>4);
    if(!r->type)return;
    int dx=wx-r->ox,dz=wz-r->oz;
    if(dx<0||dz<0||dx>=SW[r->type]||dz>=SD[r->type])return;
    int base=r->base;
    if(r->type==S_FORTRESS&&(dx%4)==0&&dz==2)for(int y=1;y<base;y++)setc(c,x,y,z,BLOCK_BRICKS);
    int floor_id=sblock(r->type,dx,0,dz,r->var);
    if(floor_id>0&&dimension==0&&colh<base&&base-colh<=4)
        for(int y=colh+1;y<base;y++)setc(c,x,y,z,floor_id==BLOCK_SNOW?BLOCK_DIRT:BLOCK_COBBLE);
    for(int dy=0;dy<=6;dy++){
        int id=sblock(r->type,dx,dy,dz,r->var);
        if(id>=0)setc(c,x,base+dy,z,(uint8_t)id);
    }
}

static void gen_over(Chunk *c,int x,int z,int wx,int wz){
    int h,b;column(wx,wz,&h,&b);
    uint32_t r=hsh(wx,0,wz,9);
    uint8_t top,fill;
    int t=vn2(wx,wz,5,3);
    switch(b){
    case B_DESERT: case B_BEACH: top=BLOCK_SAND;fill=BLOCK_SANDSTONE;break;
    case B_OCEAN: top=((r&7)==0)?BLOCK_GRAVEL:BLOCK_SAND;fill=BLOCK_SAND;break;
    case B_TUNDRA: top=BLOCK_SNOW;fill=BLOCK_DIRT;break;
    case B_MOUNTAIN: top=(h>=WORLD_Y-2||t<100)?BLOCK_SNOW:BLOCK_STONE;fill=BLOCK_STONE;break;
    case B_BADLANDS: top=BLOCK_TERRACOTTA;fill=BLOCK_TERRACOTTA;break;
    default: top=BLOCK_GRASS;fill=BLOCK_DIRT;break;
    }
    for(int y=0;y<=h;y++){
        uint8_t id;
        if(y==0)id=BLOCK_BEDROCK;
        else if(y==h)id=top;
        else if(y>=h-2){id=fill;if(b==B_BADLANDS&&(y&1))id=BLOCK_SANDSTONE;}
        else{
            id=BLOCK_STONE;
            uint32_t o=hsh(wx,y,wz,11);
            if(o%31u==0)id=BLOCK_COAL;
            else if(o%53u==1)id=BLOCK_IRON;
            else if(y<=3&&o%97u==2)id=BLOCK_GOLD;
            else if(y<=2&&o%131u==3)id=BLOCK_DIAMOND_ORE;
            else if(y<=3&&o%83u==4)id=BLOCK_REDSTONE;
            if(vn3(wx,y,wz,13)<56)id=(y==1)?BLOCK_LAVA:BLOCK_AIR;
        }
        setc(c,x,y,z,id);
    }
    if(h<SEA_LEVEL)for(int y=h+1;y<=SEA_LEVEL;y++)setc(c,x,y,z,BLOCK_WATER);
    if(b==B_SWAMP&&h<=SEA_LEVEL+1&&r%3u==0){setc(c,x,h,z,BLOCK_WATER);setc(c,x,h-1,z,BLOCK_DIRT);}
    if(h>SEA_LEVEL){
        if(b==B_DESERT&&r%19u==0&&h+3<WORLD_Y){int n=1+(int)((r>>8)%2u);for(int k=1;k<=n;k++)setc(c,x,h+k,z,BLOCK_CACTUS);}
        else if(((b==B_PLAINS&&r%11u==0)||(b==B_FOREST&&r%25u==0)||(b==B_SWAMP&&r%30u==0))&&h+1<WORLD_Y)setc(c,x,h+1,z,BLOCK_FLOWER);
        apply_tree(c,x,z,wx,wz,h,b);
    }
    apply_structure(c,x,z,wx,wz,h);
}
static void gen_nether(Chunk *c,int x,int z,int wx,int wz){
    int nh=nether_h(wx,wz);
    uint32_t r=hsh(wx,0,wz,41);
    for(int y=0;y<WORLD_Y;y++){
        uint8_t id;
        if(y==WORLD_Y-1||y==0)id=BLOCK_BEDROCK;
        else if(y>=8)id=BLOCK_NETHERRACK;
        else if(y<=nh)id=(y==nh&&r%11u==0)?BLOCK_SOUL_SAND:BLOCK_NETHERRACK;
        else if(y<=2)id=BLOCK_LAVA;
        else id=BLOCK_AIR;
        setc(c,x,y,z,id);
    }
    if(r%9u==0)setc(c,x,7,z,BLOCK_NETHERRACK);
    if(r%23u==1)setc(c,x,7,z,BLOCK_GLOWSTONE);
    if(nh>=3){
        if(r%17u==2)setc(c,x,nh+1,z,BLOCK_MAGMA);
        else if(r%29u==3)setc(c,x,nh,z,BLOCK_QUARTZ);
        else if(r%37u==4)setc(c,x,nh+1,z,BLOCK_GLOWSTONE);
    }
    apply_structure(c,x,z,wx,wz,nh);
}
static void gen_end(Chunk *c,int x,int z,int wx,int wz){
    int dx=wx-4,dz=wz-4,d2=dx*dx+dz*dz;
    uint32_t r=hsh(wx,0,wz,51);
    if(d2<=144){
        int eh=(d2<64)?3:2;
        for(int y=0;y<=eh;y++)setc(c,x,y,z,BLOCK_ENDSTONE);
        if(d2>20&&d2<110&&r%41u==0)for(int k=1;k<=2+(int)((r>>8)%2u);k++)setc(c,x,eh+k,z,BLOCK_CHORUS);
    }
    /* 4 piliers d'obsidienne (les cristaux sont des creatures posees dessus) */
    if((dx==7&&dz==0)||(dx==-7&&dz==0)||(dx==0&&dz==7)||(dx==0&&dz==-7)){
        int top=(dx>0||dz>0)?7:6;
        for(int y=1;y<=top;y++)setc(c,x,y,z,BLOCK_OBSIDIAN);
    }
}
static void apply_edits(Chunk *c){
    for(int i=0;i<n_edits;i++){
        const Edit *e=&edits[i];
        if(e->dim!=dimension)continue;
        int lx=e->x-c->cx*8,lz=e->z-c->cz*8;
        if(lx<0||lx>=8||lz<0||lz>=8||e->y>=WORLD_Y)continue;
        c->blocks[e->y*64+lz*8+lx]=e->id;
    }
}
static void generate_chunk(Chunk *c,int cx,int cz){
    memset(c->blocks,0,sizeof c->blocks);c->cx=(int16_t)cx;c->cz=(int16_t)cz;c->used=1;c->dirty=0;
    for(int z=0;z<8;z++)for(int x=0;x<8;x++){
        int wx=cx*8+x,wz=cz*8+z;
        if(dimension==0)gen_over(c,x,z,wx,wz);
        else if(dimension==1)gen_nether(c,x,z,wx,wz);
        else gen_end(c,x,z,wx,wz);
    }
    apply_edits(c);
}

/* ------------------------------ fenetre ----------------------------- */
void world_set_seed(uint32_t s){seed=s?s:1;memset(rc,0,sizeof rc);}
uint32_t world_seed(void){return seed;}
static int win_x0,win_z0,win_valid;
static void clear_world(void){memset(chunks,0,sizeof chunks);memset(rc,0,sizeof rc);win_valid=0;}
void world_init(void){dimension=0;n_edits=0;edit_next=0;clear_world();world_tick_stream(4,0,4);}
int world_dimension(void){return dimension;}
void world_set_dimension(int d,int px,int pz){dimension=(uint8_t)(d<0?0:(d>2?2:d));clear_world();world_tick_stream(px,0,pz);}
void world_rebuild(int px,int pz){clear_world();world_tick_stream(px,0,pz);}
static int in_window(int cx,int cz){return cx>=win_x0&&cx<=win_x0+1&&cz>=win_z0&&cz<=win_z0+1;}
/* Fenetre 2x2 chunks centree sur le joueur, avec hysteresis. */
void world_tick_stream(int px,int py,int pz){
    (void)py;
    if(!win_valid||px<win_x0*8+3||px>win_x0*8+12||pz<win_z0*8+3||pz>win_z0*8+12){
        win_x0=floor_div8(px-4);win_z0=floor_div8(pz-4);win_valid=1;
    }
    for(int rz=0;rz<=1;rz++)for(int rx=0;rx<=1;rx++){
        int cx=win_x0+rx,cz=win_z0+rz;
        if(slot_for(cx,cz)>=0)continue;
        int slot=-1;
        for(int i=0;i<ACTIVE_CHUNKS;i++)if(!chunks[i].used||!in_window(chunks[i].cx,chunks[i].cz)){slot=i;break;}
        if(slot<0)continue;
        generate_chunk(&chunks[slot],cx,cz);
    }
}
int world_loaded(int x,int z){return slot_for(floor_div8(x),floor_div8(z))>=0;}
uint8_t world_get(int x,int y,int z){
    if(y<0)return BLOCK_STONE;
    if(y>=WORLD_Y)return BLOCK_AIR;
    int s=slot_for(floor_div8(x),floor_div8(z));
    if(s<0)return BLOCK_AIR;
    return chunks[s].blocks[y*64+mod8(z)*8+mod8(x)];
}
static void record_edit(int x,int y,int z,uint8_t id){
    for(int i=0;i<n_edits;i++)
        if(edits[i].x==x&&edits[i].z==z&&edits[i].y==y&&edits[i].dim==dimension){edits[i].id=id;return;}
    int k;
    if(n_edits<MAX_EDITS)k=n_edits++;
    else{k=edit_next;edit_next=(edit_next+1)%MAX_EDITS;}   /* table pleine : on ecrase les plus anciens */
    edits[k]=(Edit){(int16_t)x,(int16_t)z,(uint8_t)y,id,dimension,0};
}
void world_set(int x,int y,int z,uint8_t id){
    if(y<0||y>=WORLD_Y)return;
    int s=slot_for(floor_div8(x),floor_div8(z));
    if(s<0)return;
    chunks[s].blocks[y*64+mod8(z)*8+mod8(x)]=id;
    record_edit(x,y,z,id);
}
int world_solid(int x,int y,int z){
    if(y<0)return 1;
    uint8_t id=world_get(x,y,z);
    return id!=BLOCK_AIR&&id!=BLOCK_WATER&&id!=BLOCK_LEAVES&&id!=BLOCK_TORCH&&id!=BLOCK_PORTAL&&id!=BLOCK_LAVA&&id!=BLOCK_FLOWER&&id!=BLOCK_CHORUS;
}

/* ------------------------------ spawn ------------------------------- */
int world_ground(int x,int z,int ymax){
    if(ymax>WORLD_Y-1)ymax=WORLD_Y-1;
    for(int y=ymax;y>=0;y--){
        if(!world_solid(x,y,z))continue;
        uint8_t id=world_get(x,y,z);
        if(id==BLOCK_WOOD||id==BLOCK_CACTUS||id==BLOCK_MAGMA)return -1;
        uint8_t up=world_get(x,y+1,z);
        if(up==BLOCK_WATER||up==BLOCK_LAVA)return -1;
        if(world_solid(x,y+1,z)||world_solid(x,y+2,z))return -1;
        return y+1;
    }
    return -1;
}
void world_find_spawn(int *sx,int *sy,int *sz){
    int ymax=(dimension==1)?7:WORLD_Y-1;
    for(int d=0;d<=12;d++)for(int dz=-d;dz<=d;dz++)for(int dx=-d;dx<=d;dx++){
        if((dx<0?-dx:dx)!=d&&(dz<0?-dz:dz)!=d)continue;
        int x=4+dx,z=4+dz;
        if(!world_loaded(x,z))continue;
        int g=world_ground(x,z,ymax);
        if(g>=0){*sx=x;*sy=g;*sz=z;return;}
    }
    /* Aucun sol sur dans la zone chargee : on construit une petite plateforme. */
    int py=(dimension==0)?SEA_LEVEL:3;
    uint8_t pid=(dimension==0)?BLOCK_SAND:(dimension==1?BLOCK_NETHERRACK:BLOCK_ENDSTONE);
    for(int dz=-1;dz<=1;dz++)for(int dx=-1;dx<=1;dx++){
        world_set(4+dx,py,4+dz,pid);
        world_set(4+dx,py+1,4+dz,BLOCK_AIR);
        world_set(4+dx,py+2,4+dz,BLOCK_AIR);
    }
    *sx=4;*sy=py+1;*sz=4;
}

/* ---------------------------- sauvegarde ---------------------------- */
static uint16_t const save_path[]={'\\','\\','f','l','s','0','\\','M','C','C','2','.','s','a','v',0};
int world_has_save(void){int h=BFile_Open(save_path,BFile_ReadOnly);if(h<0)return 0;BFile_Close(h);return 1;}
/* Fichier : version, graine, dimension, nombre d'edits, puis les edits. Seul le delta est ecrit. */
int world_save(void){
    uint32_t hdr[4]={WORLD_SAVE_VERSION,seed,dimension,(uint32_t)n_edits};
    int size=(int)(sizeof hdr+(unsigned)n_edits*sizeof(Edit));
    BFile_Remove(save_path);
    if(BFile_Create(save_path,BFile_File,&size)<0)return 0;
    int h=BFile_Open(save_path,BFile_WriteOnly);
    if(h<0)return 0;
    int ok=BFile_Write(h,hdr,sizeof hdr)>=0;
    if(ok&&n_edits>0)ok=BFile_Write(h,edits,(int)((unsigned)n_edits*sizeof(Edit)))>=0;
    BFile_Close(h);
    return ok;
}
int world_load(void){
    int h=BFile_Open(save_path,BFile_ReadOnly);
    if(h<0)return 0;
    uint32_t hdr[4]={0,0,0,0};
    int ok=BFile_Read(h,hdr,sizeof hdr,-1)>=0&&hdr[0]==WORLD_SAVE_VERSION&&hdr[3]<=MAX_EDITS;
    if(ok&&hdr[3]>0)ok=BFile_Read(h,edits,(int)(hdr[3]*sizeof(Edit)),-1)>=0;
    BFile_Close(h);
    if(ok){seed=hdr[1]?hdr[1]:1;dimension=(uint8_t)(hdr[2]>2?0:hdr[2]);n_edits=(int)hdr[3];edit_next=0;clear_world();}
    return ok;
}
