#include "inventory.h"
#include "input.h"
#include "config.h"
#include "world.h"
#include "render.h"
#include "texture.h"
#include "craft.h"
#include <gint/display.h>
#include <gint/keyboard.h>
#include <gint/keycodes.h>
#include <string.h>

static ItemStack inv[INVENTORY_SLOTS];
static int selected;
static int name_timer;

/* ------------------------ outils / nourriture ------------------------ */
int inventory_tool_kind(uint8_t id){
    if(id>=ITEM_PICKAXE_WOOD&&id<=ITEM_SWORD_IRON)return (id-ITEM_PICKAXE_WOOD)/3;
    if(id>=ITEM_PICKAXE_DIAMOND&&id<=ITEM_SWORD_DIAMOND)return id-ITEM_PICKAXE_DIAMOND;
    return -1;
}
int inventory_tool_tier(uint8_t id){
    if(id>=ITEM_PICKAXE_WOOD&&id<=ITEM_SWORD_IRON)return (id-ITEM_PICKAXE_WOOD)%3+1;
    if(id>=ITEM_PICKAXE_DIAMOND&&id<=ITEM_SWORD_DIAMOND)return 4;
    return 0;
}
int inventory_is_tool(uint8_t id){return inventory_tool_kind(id)>=0;}
static int tool_max(uint8_t id){
    static const int m[5]={0,40,90,160,250};
    return m[inventory_tool_tier(id)];
}
int inventory_attack_damage(void){
    /* Degats Minecraft (points de vie = moitie de coeur) : poing 1, pioche 2-5, hache 3-6, pelle 2-5, epee 4-7 */
    static const int dmg[4][5]={{1,2,3,4,5},{1,3,4,5,6},{1,2,3,4,5},{1,4,5,6,7}};
    uint8_t id=inv[selected].count?inv[selected].id:0;
    int k=inventory_tool_kind(id);
    if(k<0)return 1;
    return dmg[k][inventory_tool_tier(id)];
}
int inventory_food(uint8_t id,int *hunger,int *sat){
    int h=0,s=0;
    switch(id){
    case ITEM_APPLE: h=4;s=24;break;
    case ITEM_RAW_MEAT: h=3;s=18;break;
    case ITEM_COOKED_MEAT: h=8;s=128;break;
    case ITEM_ROTTEN: h=4;s=8;break;
    default: return 0;
    }
    *hunger=h;*sat=s;return 1;
}
const char *inventory_name(uint8_t id){
    static const char *const blocks[LAST_BLOCK+1]={"AIR","HERBE","TERRE","PIERRE","SABLE","BOIS","FEUILLES","MIN.CHARBON","MIN.FER","EAU",
        "PLANCHES","ETABLI","FOUR","VERRE","LIT","TORCHE","PAVE","GRAVIER","MIN.OR","REDSTONE","NEIGE","GRES","NETHERRACK","SABLE AMES",
        "PIERRELUM","LAVE","QUARTZ","BASALTE","PIERRE END","OBSIDIENNE","PORTAIL","PURPUR","CHORUS","MAGMA","CACTUS","FLEUR","BRIQUES","BEDROCK",
        "TERRACOTTA","MIN.DIAMANT"};
    static const char *const items[9]={"BATON","CHARBON","LINGOT FER","LINGOT OR","DIAMANT","POMME","VIANDE CRUE","STEAK","CHAIR POURRIE"};
    static const char *const tn[4]={"BOIS","PIERRE","FER","DIAMANT"};
    static const char *const kn[4]={"PIOCHE","HACHE","PELLE","EPEE"};
    static char buf[16];
    if(id<=LAST_BLOCK)return blocks[id];
    if(id>=ITEM_STICK&&id<=ITEM_ROTTEN)return items[id-ITEM_STICK];
    int k=inventory_tool_kind(id);
    if(k>=0){
        const char *a=kn[k],*b=tn[inventory_tool_tier(id)-1];
        int i=0;while(*a&&i<7)buf[i++]=*a++;buf[i++]=' ';while(*b&&i<14)buf[i++]=*b++;buf[i]=0;
        return buf;
    }
    return "?";
}

/* ------------------------------ stockage ------------------------------ */
void inventory_init(void){
    memset(inv,0,sizeof inv);
    inv[0]=(ItemStack){BLOCK_WOOD,8,0};
    inv[1]=(ItemStack){ITEM_APPLE,3,0};
    inv[2]=(ItemStack){BLOCK_TORCH,4,0};
    selected=0;name_timer=0;
}
ItemStack inventory_slot(int i){return (i<0||i>=INVENTORY_SLOTS)?(ItemStack){0,0,0}:inv[i];}
int inventory_selected(void){return selected;}
void inventory_select_delta(int delta){selected=(selected+delta+HOTBAR_SLOTS)%HOTBAR_SLOTS;name_timer=30;}
int inventory_has(uint8_t id,int n){
    int total=0;for(int i=0;i<INVENTORY_SLOTS;i++)if(inv[i].count&&inv[i].id==id)total+=inv[i].count;
    return total>=n;
}
int inventory_take(uint8_t id,int n){
    for(int i=INVENTORY_SLOTS-1;i>=0&&n>0;i--)if(inv[i].count&&inv[i].id==id){
        int k=inv[i].count<n?inv[i].count:n;inv[i].count=(uint8_t)(inv[i].count-k);n-=k;
        if(!inv[i].count){inv[i].id=BLOCK_AIR;inv[i].damage=0;}
    }
    return n==0;
}
int inventory_use_selected(int n){
    ItemStack *a=&inv[selected];
    if(a->count<n)return 0;
    a->count=(uint8_t)(a->count-n);
    if(!a->count){a->id=BLOCK_AIR;a->damage=0;}
    return 1;
}
int inventory_give(uint8_t id,int n){
    if(!id||n<=0)return 0;
    int tool=inventory_is_tool(id);
    if(!tool)for(int i=0;i<INVENTORY_SLOTS&&n>0;i++){
        if(inv[i].count&&inv[i].id==id&&inv[i].count<MAX_STACK){
            int k=MAX_STACK-inv[i].count;if(k>n)k=n;inv[i].count=(uint8_t)(inv[i].count+k);n-=k;
        }
    }
    for(int i=0;i<INVENTORY_SLOTS&&n>0;i++){
        if(inv[i].count)continue;
        int k=tool?1:(n>MAX_STACK?MAX_STACK:n);
        inv[i]=(ItemStack){id,(uint8_t)k,0};n-=k;
    }
    return n==0;
}
int inventory_room(uint8_t id,int n){
    int tool=inventory_is_tool(id),room=0;
    for(int i=0;i<INVENTORY_SLOTS;i++){
        if(!inv[i].count)room+=tool?1:MAX_STACK;
        else if(!tool&&inv[i].id==id)room+=MAX_STACK-inv[i].count;
    }
    return room>=n;
}
void inventory_damage_tool(int amount){
    ItemStack *a=&inv[selected];
    if(!a->count||!inventory_is_tool(a->id))return;
    int d=a->damage+amount;
    if(d>=tool_max(a->id)){a->count=0;a->id=BLOCK_AIR;a->damage=0;}else a->damage=(uint8_t)d;
}
void inventory_export(ItemStack *out){for(int i=0;i<INVENTORY_SLOTS;i++)out[i]=inv[i];}
void inventory_import(const ItemStack *in){for(int i=0;i<INVENTORY_SLOTS;i++)inv[i]=in[i];}

/* ---------------------------- affichage ------------------------------ */
/* Chiffres 3x5 : 5 lignes de 3 bits. */
static const uint16_t digits[10]={0x7B6F,0x2C97,0x73E7,0x73CF,0x5BC9,0x79CF,0x79EF,0x7249,0x7BEF,0x7BCF};
static void draw_digit(int x,int y,int d){
    uint16_t g=digits[d];
    for(int r=0;r<5;r++)for(int c=0;c<3;c++)if((g>>((4-r)*3+(2-c)))&1)dpixel(x+c,y+r,C_BLACK);
}
static void draw_count(int x,int y,int n){   /* x,y = coin haut-gauche, largeur 7 (2 chiffres) */
    if(n>=10){drect(x-1,y-1,x+7,y+5,C_WHITE);draw_digit(x,y,n/10);draw_digit(x+4,y,n%10);}
    else{drect(x-1,y-1,x+3,y+5,C_WHITE);draw_digit(x,y,n);}
}
static void draw_icon(uint8_t id,int x,int y){
    if(tex_icon_opaque(id))drect(x,y,x+7,y+7,C_WHITE);
    for(int v=0;v<8;v++)for(int u=0;u<8;u++)if(tex_icon_texel(id,u,v))dpixel(x+u,y+v,C_BLACK);
}
static void draw_durability(const ItemStack *a,int x,int y,int w){
    if(!inventory_is_tool(a->id))return;
    int mx=tool_max(a->id),left=mx-a->damage;if(left<0)left=0;
    dline(x,y,x+(left*w)/mx,y,C_BLACK);
}
void inventory_draw(void){
    for(int i=0;i<HOTBAR_SLOTS;i++){
        int x=1+i*14,y=51;
        drect(x,y,x+12,y+12,C_BLACK);drect(x+1,y+1,x+11,y+11,C_WHITE);
        if(i==selected){drect(x-1,y-1,x+13,y+13,C_BLACK);drect(x,y,x+12,y+12,C_WHITE);drect(x+1,y+1,x+11,y+11,C_BLACK);drect(x+2,y+2,x+10,y+10,C_WHITE);}
        ItemStack a=inv[i];
        if(a.count){
            draw_icon(a.id,x+2,y+2);
            if(a.count>1)draw_count(x+5,y+6,a.count);
            draw_durability(&a,x+2,y+10,8);
        }
    }
    if(name_timer>0){
        name_timer--;
        if(inv[selected].count){
            const char *n=inventory_name(inv[selected].id);int len=0;while(n[len])len++;
            int x=64-len*3;drect(x-2,41,x+len*6+1,48,C_WHITE);dtext(x,42,C_BLACK,n);
        }
    }
}

/* ------------------------ ecran d'inventaire ------------------------- */
/* Affichage : 3 rangees de stockage (cases 9..35) puis la hotbar (cases 0..8).
   Le curseur 'd' va de 0 a 35 dans cet ordre d'affichage. */
static int d2slot(int d){return d<27?d+9:d-27;}
static void cell_xy(int d,int *x,int *y){
    int row=d/9,col=d%9;
    *x=1+col*14;*y=8+row*11+(row==3?3:0);
}
static void quick_move(int s){
    ItemStack a=inv[s];
    if(!a.count)return;
    int to_hot=(s>=HOTBAR_SLOTS);
    int lo=to_hot?0:HOTBAR_SLOTS,hi=to_hot?HOTBAR_SLOTS:INVENTORY_SLOTS;
    if(!inventory_is_tool(a.id))
        for(int i=lo;i<hi&&a.count;i++)if(inv[i].count&&inv[i].id==a.id&&inv[i].count<MAX_STACK){
            int k=MAX_STACK-inv[i].count;if(k>a.count)k=a.count;inv[i].count=(uint8_t)(inv[i].count+k);a.count=(uint8_t)(a.count-k);
        }
    for(int i=lo;i<hi&&a.count;i++)if(!inv[i].count){inv[i]=a;a.count=0;}
    if(a.count)inv[s]=a;else inv[s]=(ItemStack){0,0,0};
}
void inventory_screen(void){
    int d=27+selected;
    ItemStack carry={0,0,0};
    for(;;){
        dclear(C_WHITE);
        dtext(1,0,C_BLACK,"INVENTAIRE");
        for(int i=0;i<INVENTORY_SLOTS;i++){
            int x,y;cell_xy(i,&x,&y);
            ItemStack a=inv[d2slot(i)];
            drect(x,y,x+13,y+10,C_BLACK);drect(x+1,y+1,x+12,y+9,C_WHITE);
            if(a.count){draw_icon(a.id,x+3,y+1);if(a.count>1)draw_count(x+7,y+4,a.count);draw_durability(&a,x+2,y+9,9);}
        }
        {int x,y;cell_xy(d,&x,&y);drect(x-1,y-1,x+14,y+11,C_BLACK);drect(x,y,x+13,y+10,C_WHITE);drect(x+1,y+1,x+12,y+9,C_BLACK);drect(x+2,y+2,x+11,y+8,C_WHITE);
         ItemStack a=inv[d2slot(d)];if(a.count){draw_icon(a.id,x+3,y+1);if(a.count>1)draw_count(x+7,y+4,a.count);}}
        if(carry.count){drect(88,0,126,7,C_WHITE);draw_icon(carry.id,90,0);draw_count(100,1,carry.count);}
        {ItemStack a=inv[d2slot(d)];const char *n=a.count?inventory_name(a.id):"";
         if(!a.count&&carry.count)n="DEPOSER";
         dtext(1,57,C_BLACK,n);if(!carry.count)dtext(80,57,C_BLACK,"F1:CRAFT");}
        dupdate();
        key_event_t ev;do{ev=getkey();}while(ev.type!=KEYEV_DOWN);
        if(ev.key==KEY_EXIT||ev.key==KEY_F5)break;
        if(ev.key==KEY_LEFT)d=(d%9==0)?d+8:d-1;
        if(ev.key==KEY_RIGHT)d=(d%9==8)?d-8:d+1;
        if(ev.key==KEY_UP)d=(d+27)%36;
        if(ev.key==KEY_DOWN)d=(d+9)%36;
        if(ev.key==KEY_F1)craft_screen(0);
        if(ev.key==KEY_EXE){
            int s=d2slot(d);
            if(ev.shift&&!carry.count)quick_move(s);
            else{
                ItemStack *c=&inv[s];
                if(!carry.count){carry=*c;*c=(ItemStack){0,0,0};}
                else if(!c->count){*c=carry;carry=(ItemStack){0,0,0};}
                else if(c->id==carry.id&&!inventory_is_tool(c->id)){
                    int k=MAX_STACK-c->count;if(k>carry.count)k=carry.count;
                    c->count=(uint8_t)(c->count+k);carry.count=(uint8_t)(carry.count-k);
                    if(!carry.count)carry=(ItemStack){0,0,0};
                }else{ItemStack t=*c;*c=carry;carry=t;}
            }
        }
    }
    if(carry.count){
        if(!inventory_is_tool(carry.id)){inventory_give(carry.id,carry.count);}
        else for(int i=0;i<INVENTORY_SLOTS;i++)if(!inv[i].count){inv[i]=carry;break;}
    }
}
