#include "player.h"
#include "input.h"
#include "world.h"
#include "inventory.h"
#include "craft.h"
#include "game.h"
#include "config.h"
#include "trig.h"
#include <gint/display.h>
#include <gint/keyboard.h>
#include <gint/keycodes.h>
#include <stdint.h>

static WorldPos p;
static int yaw,pitch,vy,grounded,hp,hunger,sat,exh,air,air_t,regen_t,lava_t;
static int pvx,pvz,fall_peak,swing_t,moving,eye_wet;

/* Collision : colonne centrale + 4 cotes, a 3 hauteurs (pieds, taille, tete). */
static int solid_player(int x,int y,int z){
    static const int ox[4]={70,-70,0,0},oz[4]={0,0,70,-70};
    int cx=x>>8,cz=z>>8,y0=y>>8,y1=(y+215)>>8,y2=(y+430)>>8;
    if(world_solid(cx,y0,cz)||world_solid(cx,y2,cz))return 1;
    for(int i=0;i<4;i++){
        int sx=(x+ox[i])>>8,sz=(z+oz[i])>>8;
        if(world_solid(sx,y0,sz)||world_solid(sx,y1,sz)||world_solid(sx,y2,sz))return 1;
    }
    return 0;
}
static void reset_vitals(void){hp=20;hunger=20;sat=50;exh=0;regen_t=0;air=10;air_t=0;lava_t=0;vy=0;pvx=0;pvz=0;}
static void place_at_spawn(void){
    int x,y,z;world_find_spawn(&x,&y,&z);
    p.x=x*256+128;p.z=z*256+128;p.y=y*256;
    grounded=0;fall_peak=p.y;
}
void player_init(void){reset_vitals();yaw=0;pitch=0;place_at_spawn();}
void player_dimension_spawn(void){place_at_spawn();vy=0;pvx=0;pvz=0;fall_peak=p.y;}
static void die(void){
    dclear(C_WHITE);dtext(30,24,C_BLACK,"VOUS ETES MORT");dtext(24,36,C_BLACK,"REAPPARITION...");dupdate();
    for(volatile int i=0;i<400000;i++){}
    if(world_dimension()!=0)world_set_dimension(0,0,0);
    game_clear_mobs();
    reset_vitals();place_at_spawn();
}
void player_respawn(void){die();}
void player_exhaust(int n){
    exh+=n;
    while(exh>=400){
        exh-=400;
        if(sat>0){sat-=10;if(sat<0)sat=0;}
        else if(hunger>0)hunger--;
    }
}
void player_damage(int amount){
    if(amount<=0)return;
    player_exhaust(30);
    hp-=amount;
    if(hp<=0)die();
}
void player_knock(int kx,int kz){pvx+=kx;pvz+=kz;}
void player_feed(int h,int s);
void player_feed(int h,int s){
    hunger+=h;if(hunger>20)hunger=20;
    sat+=s;if(sat>hunger*10)sat=hunger*10;
}
void player_start_swing(void){swing_t=6;}
int player_swing(void){return swing_t;}
int player_moving(void){return moving;}
int player_falling(void){return !grounded&&vy<0;}
int player_eye_wet(void){return eye_wet;}
int player_air(void){return air;}

void player_update(void){
    static int portal_cd;
    if(portal_cd>0)portal_cd--;
    if(swing_t>0)swing_t--;
    if(!portal_cd&&(world_get(p.x>>8,p.y>>8,p.z>>8)==BLOCK_PORTAL||world_get(p.x>>8,(p.y+430)>>8,p.z>>8)==BLOCK_PORTAL)){
        int d=(world_dimension()+1)%3;
        world_set_dimension(d,0,0);
        player_dimension_spawn();
        game_enter_dimension(d);
        portal_cd=90;
    }
    /* Camera : tourner avant de calculer le mouvement. */
    static int turn_dir_was=0,turn_hold=0;
    int left=input_down(KEY_LEFT),right=input_down(KEY_RIGHT);
    int turn_dir=right-left;
    if(turn_dir==0||turn_dir!=turn_dir_was)turn_hold=0;
    if(turn_dir){
        int step=TURN_MIN_DEG+turn_hold/TURN_RAMP_FRAMES;if(step>TURN_MAX_DEG)step=TURN_MAX_DEG;
        yaw=((yaw+turn_dir*step)%360+360)%360;
        turn_hold++;
    }
    turn_dir_was=turn_dir;
    static int f3_was=0,f4_was=0;
    int f3=input_down(KEY_F3),f4=input_down(KEY_F4);
    if(f3&&!f3_was)inventory_select_delta(-1);
    if(f4&&!f4_was)inventory_select_delta(1);
    f3_was=f3;f4_was=f4;

    /* Milieu : eau / lave */
    int wet=(world_get(p.x>>8,p.y>>8,p.z>>8)==BLOCK_WATER)||(world_get(p.x>>8,(p.y+215)>>8,p.z>>8)==BLOCK_WATER);
    int lava=(world_get(p.x>>8,p.y>>8,p.z>>8)==BLOCK_LAVA)||(world_get(p.x>>8,(p.y+215)>>8,p.z>>8)==BLOCK_LAVA);
    eye_wet=(world_get(p.x>>8,(p.y+EYE_HEIGHT)>>8,p.z>>8)==BLOCK_WATER);
    int fluid=wet||lava;

    int fwd=input_down(KEY_UP)?22:(input_down(KEY_DOWN)?-18:0);
    int str=input_down(KEY_SHIFT)?-12:(input_down(KEY_ALPHA)?12:0);
    if(fluid){fwd=fwd*2/3;str=str*2/3;}
    moving=(fwd||str);
    int dx=(isin(yaw)*fwd+icos(yaw)*str)/256+pvx,dz=(icos(yaw)*fwd-isin(yaw)*str)/256+pvz;
    pvx=pvx*3/4;pvz=pvz*3/4;
    int nx=p.x+dx,nz=p.z+dz;
    if(!solid_player(nx,p.y,p.z))p.x=nx;
    if(!solid_player(p.x,p.y,nz))p.z=nz;

    int jump=input_down(KEY_EXE);
    if(fluid){
        vy-=2;if(vy<-40)vy=-40;
        if(jump){if(eye_wet){vy+=10;if(vy>45)vy=45;}else vy=55;}   /* nager / sortir de l'eau */
        player_exhaust(1);
    }else{
        vy-=GRAVITY;if(vy<-180)vy=-180;
        if(jump&&grounded){vy=JUMP_V;player_exhaust(5);}
    }
    int ny=p.y+vy;
    if(!solid_player(p.x,ny,p.z)){p.y=ny;grounded=0;}
    else{
        if(vy<0){
            /* Degats de chute Minecraft : 1 point par bloc au-dela de 3. */
            if(!fluid){int dist=(fall_peak-p.y)>>8;if(dist>3)player_damage(dist-3);}
            p.y=(p.y>>8)<<8;grounded=1;fall_peak=p.y;
        }
        vy=0;
    }
    if(grounded||fluid)fall_peak=p.y;else if(p.y>fall_peak)fall_peak=p.y;
    if(moving)player_exhaust(1);

    /* Noyade et lave */
    if(eye_wet){air_t++;if(air_t>=15){air_t=0;if(air>0)air--;else player_damage(2);}}
    else{air=10;air_t=0;}
    if(lava){lava_t++;if(lava_t>=10){lava_t=0;player_damage(3);}}else lava_t=0;

    if(p.y<128)die();

    /* Faim et regeneration (regles de Minecraft : >= 18 de faim soigne, 0 affame) */
    if(hunger>=18){
        regen_t++;
        int fast=(hunger>=20&&sat>0);
        if(regen_t>=(fast?HEAL_FAST:HEAL_SLOW)){
            regen_t=0;
            if(hp<20){hp++;player_exhaust(fast?300:600);}
        }
    }else if(hunger<=0){
        regen_t++;
        if(regen_t>=STARVE_FRAMES){regen_t=0;if(hp>1)player_damage(1);}
    }else regen_t=0;
}
void player_eye(int *x,int *y,int *z){*x=p.x;*y=p.y+EYE_HEIGHT;*z=p.z;}
void player_pos(int *x,int *y,int *z){*x=p.x;*y=p.y;*z=p.z;}

/* Voxel DDA depuis l'oeil. Les liquides et portails sont traverses (on vise ce qu'il y a dessous). */
static int raycast(int *bx,int *by,int *bz,int *px,int *py,int *pz){
    int ex,ey,ez;player_eye(&ex,&ey,&ez);
    int dx=isin(yaw),dz=icos(yaw),dy=pitch*4;
    int ix=ex>>8,iy=ey>>8,iz=ez>>8;
    const int INF=0x3fffffff;
    int adx=dx<0?-dx:dx,ady=dy<0?-dy:dy,adz=dz<0?-dz:dz;
    int tx=adx?((dx>0?((ix+1)<<8)-ex:ex-(ix<<8))*256)/adx:INF;
    int ty=ady?((dy>0?((iy+1)<<8)-ey:ey-(iy<<8))*256)/ady:INF;
    int tz=adz?((dz>0?((iz+1)<<8)-ez:ez-(iz<<8))*256)/adz:INF;
    int tdx=adx?65536/adx:INF,tdy=ady?65536/ady:INF,tdz=adz?65536/adz:INF;
    for(int step=0;step<16;step++){
        int prevx=ix,prevy=iy,prevz=iz,t;
        if(tx<=ty&&tx<=tz){t=tx;ix+=dx>0?1:-1;tx+=tdx;}
        else if(ty<=tz){t=ty;iy+=dy>0?1:-1;ty+=tdy;}
        else{t=tz;iz+=dz>0?1:-1;tz+=tdz;}
        if(t>1152)return 0;
        uint8_t b=world_get(ix,iy,iz);
        if(b!=BLOCK_AIR&&b!=BLOCK_WATER&&b!=BLOCK_LAVA&&b!=BLOCK_PORTAL){*bx=ix;*by=iy;*bz=iz;*px=prevx;*py=prevy;*pz=prevz;return 1;}
    }
    return 0;
}
/* Palier de pioche necessaire pour obtenir le butin d'un bloc (0 = a la main). */
static int block_tier(uint8_t id){
    switch(id){
    case BLOCK_STONE: case BLOCK_COBBLE: case BLOCK_COAL: case BLOCK_SANDSTONE: case BLOCK_NETHERRACK:
    case BLOCK_QUARTZ: case BLOCK_BASALT: case BLOCK_ENDSTONE: case BLOCK_PURPUR: case BLOCK_MAGMA:
    case BLOCK_FURNACE: case BLOCK_BRICKS: case BLOCK_TERRACOTTA: return 1;
    case BLOCK_IRON: return 2;
    case BLOCK_GOLD: case BLOCK_REDSTONE: case BLOCK_DIAMOND_ORE: return 3;
    case BLOCK_OBSIDIAN: return 4;
    default: return 0;
    }
}
int player_break_block(void){
    int bx,by,bz,px,py,pz;
    player_start_swing();
    if(!raycast(&bx,&by,&bz,&px,&py,&pz))return 0;
    uint8_t id=world_get(bx,by,bz);
    if(id==BLOCK_BEDROCK)return 0;
    ItemStack held=inventory_slot(inventory_selected());
    int pick=(held.count&&inventory_tool_kind(held.id)==0)?inventory_tool_tier(held.id):0;
    int drop=1;
    if(block_tier(id)>pick)drop=0;                /* mauvaise pioche : le bloc casse mais ne donne rien */
    world_set(bx,by,bz,BLOCK_AIR);
    player_exhaust(5);
    if(drop){
        switch(id){
        case BLOCK_STONE: inventory_give(BLOCK_COBBLE,1);break;
        case BLOCK_COAL: inventory_give(ITEM_COAL,1);break;
        case BLOCK_DIAMOND_ORE: inventory_give(ITEM_DIAMOND,1);break;
        case BLOCK_GRASS: inventory_give(BLOCK_DIRT,1);break;
        case BLOCK_GLASS: break;
        case BLOCK_LEAVES: if((((bx*7)^(by*13)^(bz*29))&15)==0)inventory_give(ITEM_APPLE,1);break;
        default: inventory_give(id,1);break;
        }
    }
    inventory_damage_tool(1);
    return 1;
}
int player_place_block(void){
    int bx,by,bz,px,py,pz;
    ItemStack a=inventory_slot(inventory_selected());
    if(!a.count||a.id==BLOCK_AIR||a.id>LAST_BLOCK)return 0;
    if(!raycast(&bx,&by,&bz,&px,&py,&pz))return 0;
    uint8_t cur=world_get(px,py,pz);
    if(cur!=BLOCK_AIR&&cur!=BLOCK_WATER&&cur!=BLOCK_LAVA)return 0;
    if(py<=0||py>=WORLD_Y)return 0;
    if(a.id!=BLOCK_TORCH&&a.id!=BLOCK_FLOWER&&px==(p.x>>8)&&pz==(p.z>>8)&&py>=(p.y>>8)&&py<=((p.y+430)>>8))return 0;
    world_set(px,py,pz,a.id);
    player_start_swing();
    return inventory_use_selected(1);
}
int player_use(void){
    int bx,by,bz,px,py,pz;
    if(raycast(&bx,&by,&bz,&px,&py,&pz)){
        uint8_t id=world_get(bx,by,bz);
        if(id==BLOCK_CRAFTING){craft_screen(1);return 1;}
        if(id==BLOCK_FURNACE){furnace_screen();return 1;}
        if(id==BLOCK_BED){game_sleep();return 1;}
    }
    ItemStack a=inventory_slot(inventory_selected());
    int h,s;
    if(a.count&&inventory_food(a.id,&h,&s)){
        if(hunger>=20){game_message("PAS FAIM");return 1;}
        inventory_use_selected(1);
        player_feed(h,s);
        if(a.id==ITEM_ROTTEN&&hp>2)player_damage(1);   /* chair pourrie : mauvais pour la sante */
        player_start_swing();
        return 1;
    }
    return player_place_block();
}
int player_x(void){return p.x>>8;}int player_y(void){return p.y>>8;}int player_z(void){return p.z>>8;}
int player_yaw(void){return yaw;}int player_pitch(void){return pitch;}
int player_health(void){return hp;}int player_hunger(void){return hunger;}
void player_export(PlayerState *s){
    s->pos=p;s->yaw=(int16_t)yaw;s->pitch=(int16_t)pitch;s->vy=(int16_t)vy;s->hp=(int16_t)hp;s->hunger=(int16_t)hunger;s->sat=(int16_t)sat;
}
void player_import(const PlayerState *s){
    p=s->pos;yaw=s->yaw;pitch=s->pitch;vy=s->vy;hp=s->hp;hunger=s->hunger;sat=s->sat;
    exh=0;regen_t=0;air=10;air_t=0;lava_t=0;pvx=0;pvz=0;grounded=0;fall_peak=p.y;
}
