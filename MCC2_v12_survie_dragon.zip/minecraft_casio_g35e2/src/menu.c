#include "menu.h"
#include "world.h"
#include "player.h"
#include "inventory.h"
#include "render.h"
#include "save.h"
#include "game.h"
#include "texture.h"
#include <gint/display.h>
#include <gint/keyboard.h>
#include <gint/keycodes.h>

/* Use getkey() events instead of polling keydown() in a tight loop. */
static key_event_t wait_key_down(void)
{
    key_event_t ev;
    do {
        ev = getkey();
    } while(ev.type != KEYEV_DOWN);
    return ev;
}

static void title(void)
{
    dclear(C_WHITE);
    dtext(36, 2, C_BLACK, "MINECRAFT");
    dtext(27, 10, C_BLACK, "CASIO EDITION");
}

static void start_new_world(int fixed_seed)
{
    if(fixed_seed) world_set_seed(0x2468ACE1u);
    world_init();
    inventory_init();
    player_init();
    game_init();
}

static void show_options(void)
{
    dclear(C_WHITE);
    dtext(39, 0, C_BLACK, "COMMANDES");
    dtext(2, 8, C_BLACK, "HAUT/BAS: AVANCER");
    dtext(2, 15, C_BLACK, "GAUCHE/DROITE: TOURNER");
    dtext(2, 22, C_BLACK, "SHIFT/ALPHA: PAS LATERAL");
    dtext(2, 29, C_BLACK, "EXE: SAUTER / NAGER");
    dtext(2, 36, C_BLACK, "F1: FRAPPER / CASSER");
    dtext(2, 43, C_BLACK, "F2: POSER/MANGER/UTILISER");
    dtext(2, 50, C_BLACK, "F3/F4: CASE  F5: SAC");
    dtext(2, 57, C_BLACK, "SHIFT+F5: CRAFT 2X2");
    dupdate();
    for(;;) {
        key_event_t ev = wait_key_down();
        if(ev.key == KEY_EXIT || ev.key == KEY_EXE) return;
    }
}

int menu_run(void)
{
    int selected = 0;
    static char const *items[5] = {"JOUER", "NOUVEAU MONDE", "TEXTURES", "COMMANDES", "QUITTER"};

    for(;;) {
        title();
        for(int i = 0; i < 5; i++) {
            int y = 20 + i * 8;
            int len = 0;
            while(items[i][len]) len++;
            int x = 64 - len * 3;
            if(i == selected) {
                drect(14, y - 1, 114, y + 6, C_BLACK);
                dtext(x, y, C_WHITE, items[i]);
            } else {
                dtext(x, y, C_BLACK, items[i]);
            }
        }
        dupdate();

        key_event_t ev = wait_key_down();
        if(ev.key == KEY_UP) {
            selected = (selected + 4) % 5;
        } else if(ev.key == KEY_DOWN) {
            selected = (selected + 1) % 5;
        } else if(ev.key == KEY_EXE) {
            if(selected == 0) {
                /* If no usable save exists, start a fresh world. */
                if(!save_exists() || !load_game()) start_new_world(0);
                return 1;
            }
            if(selected == 1) {
                start_new_world(1);
                save_game();
                return 1;
            }
            if(selected == 2) {
                texture_editor();
            } else if(selected == 3) {
                show_options();
            } else {
                return 0;
            }
        } else if(ev.key == KEY_EXIT) {
            return 0;
        }
    }
}

int menu_pause(void)
{
    dclear(C_WHITE);
    dtext(45, 2, C_BLACK, "PAUSE");
    dtext(8, 14, C_BLACK, "EXE: REPRENDRE");
    dtext(8, 24, C_BLACK, "F1: SAUVEGARDER");
    dtext(8, 34, C_BLACK, "F2: TEXTURES");
    dtext(8, 44, C_BLACK, "F5: INVENTAIRE");
    dtext(8, 54, C_BLACK, "EXIT: MENU PRINCIPAL");
    dupdate();
    for(;;) {
        key_event_t ev = wait_key_down();
        if(ev.key == KEY_EXE) return 1;
        if(ev.key == KEY_F1) { save_game(); return 1; }
        if(ev.key == KEY_F2) { texture_editor(); return 1; }
        if(ev.key == KEY_F5) { inventory_screen(); return 1; }
        if(ev.key == KEY_EXIT) return 0;
    }
}
