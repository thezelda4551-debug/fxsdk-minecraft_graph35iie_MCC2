#include "menu.h"
#include "input.h"
#include "world.h"
#include "player.h"
#include "inventory.h"
#include "render.h"
#include "save.h"
#include "game.h"
#include "texture.h"
#include "craft.h"
#include <gint/display.h>
#include <gint/keyboard.h>
#include <gint/keycodes.h>
int main(void){
    render_init();
    texture_init();texture_load();
    for(;;){
        if(!menu_run())break;
        input_reset();
        int running=1; int exit_was=0,f1_was=0,f2_was=0,f5_was=0;
        while(running){
            /* Drain gint keyboard events every frame before reading key states. */
            input_begin_frame();
            int ex=input_down(KEY_EXIT),f1=input_down(KEY_F1),f2=input_down(KEY_F2),f5=input_down(KEY_F5),sh=input_down(KEY_SHIFT);
            if(ex&&!exit_was){running=menu_pause();input_reset();}
            if(f1&&!f1_was){if(!game_attack())player_break_block();}
            if(f2&&!f2_was){player_use();input_reset();}
            if(f5&&!f5_was){if(sh)craft_screen(0);else inventory_screen();input_reset();}
            exit_was=ex;f1_was=f1;f2_was=f2;f5_was=f5;
            player_update(); world_tick_stream(player_x(),player_y(),player_z()); game_tick(); render_frame();
        }
        save_game();
    }
    dclear(C_WHITE);dupdate();return 1;
}
