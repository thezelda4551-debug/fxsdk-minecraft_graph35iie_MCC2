#include "game.h"
#include "config.h"
#include "player.h"
#include "world.h"
#include "inventory.h"
#include "trig.h"
#include <gint/display.h>
#include <gint/keyboard.h>
#include <gint/keycodes.h>
#include <string.h>

static uint32_t ticks;
static Mob mobs[MAX_MOBS];
static uint32_t rs=2463534242u;
static uint32_t rnd(void){rs^=rs<<13;rs^=rs>>17;rs^=rs<<5;return rs;}
static int isqrt(int n){int r=0,b=1<<30;if(n<=0)return 0;while(b>n)b>>=2;while(b){if(n>=r+b){n-=r+b;r=(r>>1)+b;}else r>>=1;b>>=2;}return r;}
static int iabs(int a){return a<0?-a:a;}

/* ------------------------------ messages ------------------------------ */
static char msg[24];static int msg_t;
void game_message(const char *s){int i=0;while(s[i]&&i<23){msg[i]=s[i];i++;}msg[i]=0;msg_t=45;}

/* -------------------------------- dragon ------------------------------ */
typedef struct { fxp x,y,z; int hp; int phase,timer,hurt,cd,alive,ang,heal; } Dragon;
static Dragon dr;
static uint8_t dragon_dead;
#define END_CX (4*256+128)
#define END_CZ (4*256+128)

/* ------------------------------ creatures ----------------------------- */
static int mob_h(int t){switch(t){case MOB_COW:case MOB_PIG:return 230;case MOB_ZOMBIE:return 480;case MOB_CREEPER:return 440;default:return 256;}}
static int mob_hp(int t){switch(t){case MOB_COW:case MOB_PIG:return 10;case MOB_ZOMBIE:case MOB_CREEPER:return 20;default:return 1;}}
static int mob_speed(int t){switch(t){case MOB_ZOMBIE:case MOB_CREEPER:return 11;default:return 5;}}
static int hostile(int t){return t==MOB_ZOMBIE||t==MOB_CREEPER;}

void game_clear_mobs(void){memset(mobs,0,sizeof mobs);dr.alive=0;}
static Mob *new_mob(int type,fxp x,fxp y,fxp z){
    for(int i=0;i<MAX_MOBS;i++)if(!mobs[i].alive){
        Mob *m=&mobs[i];memset(m,0,sizeof *m);
        m->alive=1;m->type=(uint8_t)type;m->x=x;m->y=y;m->z=z;m->hp=(int16_t)mob_hp(type);m->timer=1;
        return m;
    }
    return 0;
}
void game_enter_dimension(int d){
    game_clear_mobs();
    if(d==2){
        static const int cx[4]={11,-3,4,4},cz[4]={4,4,11,-3};
        for(int i=0;i<4;i++){
            /* le cristal repose sur le pilier (sommet y=7 ou 6) */
            new_mob(MOB_CRYSTAL,cx[i]*256+128,(((cx[i]>4||cz[i]>4)?7:6)+1)*256,cz[i]*256+128);
        }
        if(!dragon_dead){
            memset(&dr,0,sizeof dr);
            dr.alive=1;dr.hp=DRAGON_HP;dr.x=END_CX+7*256;dr.y=5*256;dr.z=END_CZ;dr.phase=0;dr.timer=300;
            game_message("L'ENDER DRAGON !");
        }
    }
}
void game_init(void){ticks=0;msg_t=0;game_clear_mobs();dragon_dead=0;if(world_dimension()==2)game_enter_dimension(2);}
uint32_t game_time(void){return ticks;}
int game_daylight(void){uint32_t t=ticks%DAY_TICKS;return t<(DAY_TICKS/2)?1:0;}

static int mob_blocked(const Mob *m,int nx,int nz){
    int cx=nx>>8,cz=nz>>8,y0=m->y>>8,y1=(m->y+mob_h(m->type)-1)>>8;
    for(int y=y0;y<=y1;y++)if(world_solid(cx,y,cz))return 1;
    return 0;
}
static void explode(int x,int y,int z,int radius_sq,int dmg_max){
    int bx=x>>8,by=y>>8,bz=z>>8;
    for(int dz=-2;dz<=2;dz++)for(int dy=-2;dy<=2;dy++)for(int dx=-2;dx<=2;dx++){
        if(dx*dx+dy*dy+dz*dz>radius_sq)continue;
        uint8_t id=world_get(bx+dx,by+dy,bz+dz);
        if(id==BLOCK_AIR||id==BLOCK_BEDROCK||id==BLOCK_OBSIDIAN||id==BLOCK_PORTAL||id==BLOCK_WATER||id==BLOCK_LAVA)continue;
        if(by+dy<=0)continue;
        world_set(bx+dx,by+dy,bz+dz,BLOCK_AIR);
    }
    int px,py,pz;player_pos(&px,&py,&pz);
    int dx=px-x,dz=pz-z,dist=isqrt(dx*dx+dz*dz);
    if(dist<4*256&&iabs(py-y)<3*256){
        player_damage(dmg_max*(4*256-dist)/(4*256)+1);
        if(dist>0)player_knock(dx*60/dist,dz*60/dist);
    }
}
static void kill_mob(Mob *m){
    m->alive=0;
    switch(m->type){
    case MOB_COW: case MOB_PIG: inventory_give(ITEM_RAW_MEAT,1+(int)(rnd()%2));break;
    case MOB_ZOMBIE: if(rnd()%3){inventory_give(ITEM_ROTTEN,1+(int)(rnd()%2));}break;
    case MOB_CREEPER: if(rnd()&1)inventory_give(ITEM_COAL,1);break;
    case MOB_CRYSTAL: explode(m->x,m->y,m->z,2,4);break;
    }
}
static void update_mob(Mob *m){
    if(m->hurt)m->hurt--;
    if(m->cd)m->cd--;
    if(m->type==MOB_CRYSTAL)return;
    int px,py,pz;player_pos(&px,&py,&pz);
    int dx=px-m->x,dz=pz-m->z,dist=isqrt(dx*dx+dz*dz);
    if(!world_loaded(m->x>>8,m->z>>8)||dist>18*256){m->alive=0;return;}
    int spd=mob_speed(m->type),sx=0,sz=0;
    if(hostile(m->type)&&dist<10*256&&dist>0){
        sx=dx*spd/dist;sz=dz*spd/dist;
        if(m->type==MOB_CREEPER){
            if(dist<3*256){sx=sz=0;m->fuse++;if(m->fuse>=30){explode(m->x,m->y,m->z,5,9);m->alive=0;return;}}
            else if(m->fuse>0)m->fuse--;
        }else if(dist<200&&iabs(py-m->y)<400&&!m->cd){
            player_damage(3);if(dist>0)player_knock(dx*30/dist,dz*30/dist);m->cd=30;
        }
    }else{
        static const int8_t ddx[8]={1,1,0,-1,-1,-1,0,1},ddz[8]={0,1,1,1,0,-1,-1,-1};
        if(m->timer>0)m->timer--;
        if(!m->timer){m->timer=(uint8_t)(40+rnd()%60);m->dir=(uint8_t)(rnd()%9);}
        int flee=(!hostile(m->type)&&m->fuse>0);
        if(flee){m->fuse--;if(dist>0){sx=-dx*spd*2/dist;sz=-dz*spd*2/dist;}}
        else if(m->dir<8){sx=ddx[m->dir]*spd;sz=ddz[m->dir]*spd;}
    }
    int nx=m->x+sx+m->vx,nz=m->z+sz+m->vz;
    m->vx=(int16_t)(m->vx*3/4);m->vz=(int16_t)(m->vz*3/4);
    if(!mob_blocked(m,nx,m->z))m->x=nx;else if(m->gnd&&(sx||sz||m->vx))m->vy=70;
    if(!mob_blocked(m,m->x,nz))m->z=nz;else if(m->gnd&&(sx||sz||m->vz))m->vy=70;
    int inwater=(world_get(m->x>>8,m->y>>8,m->z>>8)==BLOCK_WATER);
    if(inwater){m->vy+=3;if(m->vy>20)m->vy=20;}else{m->vy-=GRAVITY;if(m->vy<-150)m->vy=-150;}
    int ny=m->y+m->vy;
    if(world_solid(m->x>>8,ny>>8,m->z>>8)){
        if(m->vy<0){m->y=((ny>>8)+1)<<8;m->gnd=1;}
        m->vy=0;
    }else{m->y=ny;m->gnd=0;}
    if(m->y<256){m->alive=0;}
}
static void try_spawn(void){
    int d=world_dimension();
    if(d==2)return;
    int nh=0,np=0;
    for(int i=0;i<MAX_MOBS;i++)if(mobs[i].alive){if(hostile(mobs[i].type))nh++;else np++;}
    int night=!game_daylight(),px=player_x(),pz=player_z();
    for(int t=0;t<10;t++){
        int x=px+(int)(rnd()%9)-4,z=pz+(int)(rnd()%9)-4;
        if(iabs(x-px)<3&&iabs(z-pz)<3)continue;
        if(!world_loaded(x,z))continue;
        int g=world_ground(x,z,d==1?7:WORLD_Y-1);
        if(g<0)continue;
        uint8_t below=world_get(x,g-1,z);
        int type;
        if(d==1||night){
            if(nh>=3)return;
            type=(d==0&&rnd()%3==0)?MOB_CREEPER:MOB_ZOMBIE;
        }else{
            if(np>=3||below!=BLOCK_GRASS)continue;
            type=(rnd()&1)?MOB_COW:MOB_PIG;
        }
        new_mob(type,x*256+128,g*256,z*256+128);
        return;
    }
}

/* -------------------------------- dragon IA --------------------------- */
static void move_toward(Dragon *d,int tx,int ty,int tz,int speed){
    int dx=tx-d->x,dy=ty-d->y,dz=tz-d->z,dist=isqrt(dx*dx+dy*dy+dz*dz);
    if(dist<=speed||dist==0){d->x=tx;d->y=ty;d->z=tz;return;}
    d->x+=dx*speed/dist;d->y+=dy*speed/dist;d->z+=dz*speed/dist;
}
static void dragon_die(void){
    dr.alive=0;dragon_dead=1;
    for(int i=0;i<MAX_MOBS;i++)if(mobs[i].alive&&mobs[i].type==MOB_CRYSTAL)mobs[i].alive=0;
    /* portail de sortie au centre de l'ile (persiste dans la sauvegarde) */
    world_set(4,4,4,BLOCK_PORTAL);world_set(4,5,4,BLOCK_PORTAL);
    game_message("DRAGON VAINCU !");
}
static void update_dragon(void){
    if(!dr.alive)return;
    if(dr.hurt)dr.hurt--;
    if(dr.cd)dr.cd--;
    int crystals=0;
    for(int i=0;i<MAX_MOBS;i++)if(mobs[i].alive&&mobs[i].type==MOB_CRYSTAL)crystals++;
    if(crystals&&++dr.heal>=20){dr.heal=0;if(dr.hp<DRAGON_HP)dr.hp+=crystals;if(dr.hp>DRAGON_HP)dr.hp=DRAGON_HP;}
    int px,py,pz;player_pos(&px,&py,&pz);
    dr.timer--;
    switch(dr.phase){
    case 0:{   /* vol en cercle autour de l'ile */
        dr.ang=(dr.ang+3)%360;
        int tx=END_CX+(icos(dr.ang)*7*256)/256,tz=END_CZ+(isin(dr.ang)*7*256)/256;
        int ty=5*256+(isin(dr.ang*2)*200)/256;
        move_toward(&dr,tx,ty,tz,24);
        if(dr.timer<=0){dr.phase=1;dr.timer=150;}
        break;}
    case 1:{   /* charge sur le joueur */
        move_toward(&dr,px,py+128,pz,22);
        int dx=px-dr.x,dz=pz-dr.z,dy=py+128-dr.y;
        if(dx*dx+dz*dz+dy*dy<358*358&&!dr.cd){
            player_damage(6);
            int d=isqrt(dx*dx+dz*dz);if(d>0)player_knock(dx*50/d,dz*50/d);
            dr.cd=40;dr.phase=0;dr.timer=240;
        }
        if(dr.timer<=0){dr.phase=(rnd()&1)?2:0;dr.timer=(dr.phase==2)?200:240;}
        break;}
    default:   /* pose au centre : vulnerable (degats doubles) */
        move_toward(&dr,END_CX,4*256,END_CZ,18);
        if(dr.timer<=0){dr.phase=0;dr.timer=300;}
        break;
    }
}

/* ------------------------------- combat ------------------------------- */
int game_dragon(int *x,int *y,int *z,int *hurt){
    if(!dr.alive)return 0;
    *x=dr.x;*y=dr.y;*z=dr.z;*hurt=dr.hurt;return 1;
}
static int attack_cd;
int game_attack(void){
    int px,py,pz;player_pos(&px,&py,&pz);
    int fx=isin(player_yaw()),fz=icos(player_yaw());
    int best=-1,bestd=0x7fffffff,target_dragon=0;
    for(int i=0;i<MAX_MOBS;i++){
        Mob *m=&mobs[i];if(!m->alive)continue;
        int vx=m->x-px,vz=m->z-pz,d2=vx*vx+vz*vz;
        if(d2>819*819)continue;
        int dot=(vx*fx+vz*fz)>>8;
        if(dot<=0||dot*dot*5<d2*2)continue;
        int mid=m->y+mob_h(m->type)/2;
        if(iabs(mid-(py+215))>mob_h(m->type)/2+320)continue;
        if(d2<bestd){bestd=d2;best=i;}
    }
    if(dr.alive){
        int vx=dr.x-px,vz=dr.z-pz,d2=vx*vx+vz*vz;
        if(d2<=1203*1203){
            int dot=(vx*fx+vz*fz)>>8;
            if(dot>0&&dot*dot*10>=d2*3&&iabs(dr.y-(py+215))<=600&&d2<bestd){bestd=d2;best=-1;target_dragon=1;}
        }
    }
    if(best<0&&!target_dragon)return 0;
    player_start_swing();
    if(attack_cd>0)return 1;
    attack_cd=8;
    int dmg=inventory_attack_damage();
    if(player_falling())dmg=dmg*3/2;           /* coup critique en chute */
    player_exhaust(10);
    inventory_damage_tool(inventory_tool_kind(inventory_slot(inventory_selected()).id)==3?1:2);
    if(target_dragon){
        if(dr.phase==2)dmg*=2;
        dr.hp-=dmg;dr.hurt=6;
        if(dr.hp<=0)dragon_die();
    }else{
        Mob *m=&mobs[best];
        m->hp=(int16_t)(m->hp-dmg);m->hurt=6;
        if(m->type!=MOB_CRYSTAL){
            m->vx=(int16_t)(fx*30/256);m->vz=(int16_t)(fz*30/256);m->vy=40;
            if(!hostile(m->type))m->fuse=40;        /* les animaux passifs fuient */
        }
        if(m->hp<=0)kill_mob(m);
    }
    return 1;
}

/* -------------------------------- boucle ------------------------------ */
void game_tick(void){
    ticks++;if(ticks>=DAY_TICKS)ticks=0;
    if(attack_cd>0)attack_cd--;
    if(msg_t>0)msg_t--;
    for(int i=0;i<MAX_MOBS;i++)if(mobs[i].alive)update_mob(&mobs[i]);
    if(world_dimension()==2)update_dragon();
    if(ticks%120==0)try_spawn();
    /* les zombies disparaissent au lever du jour */
    if(game_daylight()&&world_dimension()==0&&ticks%60==0)
        for(int i=0;i<MAX_MOBS;i++)if(mobs[i].alive&&hostile(mobs[i].type)&&rnd()%3==0)mobs[i].alive=0;
}
int game_mob(int i,int *x,int *y,int *z,int *type,int *hurt,int *fuse){
    if(i<0||i>=MAX_MOBS||!mobs[i].alive)return 0;
    *x=mobs[i].x;*y=mobs[i].y;*z=mobs[i].z;*type=mobs[i].type;*hurt=mobs[i].hurt;*fuse=hostile(mobs[i].type)?mobs[i].fuse:0;
    return 1;
}
static void icon_box(int x,int y,int full,int half){   /* 3x3 : plein / demi / vide (contour) */
    if(full){drect(x,y,x+2,y+2,C_BLACK);return;}
    drect(x,y,x+2,y+2,C_WHITE);
    drect(x,y,x+2,y,C_BLACK);drect(x,y+2,x+2,y+2,C_BLACK);
    dpixel(x,y+1,C_BLACK);
    if(half)dpixel(x+1,y+1,C_BLACK);else dpixel(x+2,y+1,C_BLACK);
}
void game_draw_hud(void){
    int hp=player_health(),hu=player_hunger();
    dtext(1,1,C_BLACK,"HP");
    for(int i=0;i<10;i++)icon_box(13+i*5,2,hp>=i*2+2,hp==i*2+1);
    dtext(70,1,C_BLACK,"F");
    for(int i=0;i<10;i++)icon_box(79+(9-i)*4,2,hu>=i*2+2,hu==i*2+1);
    if(player_eye_wet()||player_air()<10){
        int a=player_air();
        for(int i=0;i<a;i++){int x=79+(9-i)*4;drect(x,8,x+2,10,C_BLACK);dpixel(x+1,9,C_WHITE);}
    }
    if(dr.alive){
        drect(16,7,111,11,C_BLACK);drect(17,8,110,10,C_WHITE);
        drect(17,8,17+(93*dr.hp)/DRAGON_HP,10,C_BLACK);
        dtext(46,12,C_BLACK,"ENDER DRAGON");
    }
    if(msg_t>0){int len=0;while(msg[len])len++;int x=64-len*3;drect(x-2,34,x+len*6,41,C_WHITE);dtext(x,35,C_BLACK,msg);}
}
void game_sleep(void){
    if(game_daylight()){game_message("PAS MAINTENANT");return;}
    ticks=0;
    dclear(C_WHITE);dtext(31,27,C_BLACK,"BONNE NUIT");dupdate();
    for(volatile int i=0;i<200000;i++){}
    game_message("BONJOUR !");
}
void game_export(uint32_t *time,uint8_t *flags){*time=ticks;*flags=dragon_dead;}
void game_import(uint32_t time,uint8_t flags){ticks=time%DAY_TICKS;dragon_dead=flags&1;game_clear_mobs();if(world_dimension()==2)game_enter_dimension(2);}
