#include "save.h"
#include "world.h"
#include "player.h"
#include "inventory.h"
#include "game.h"
#include "config.h"
#include <gint/bfile.h>
#include <stdint.h>
static uint16_t const meta_path[]={'\\','\\','f','l','s','0','\\','M','C','C','2','P','A','R','T','.','s','a','v',0};
typedef struct { uint32_t version; PlayerState ps; uint32_t time; uint8_t flags,sel,pad[2]; ItemStack inv[INVENTORY_SLOTS]; } SaveMeta;
int save_exists(void){int h=BFile_Open(meta_path,BFile_ReadOnly);if(h<0)return 0;BFile_Close(h);return world_has_save();}
int save_game(void){
    if(!world_save())return 0;
    SaveMeta m;
    m.version=WORLD_SAVE_VERSION;
    player_export(&m.ps);inventory_export(m.inv);game_export(&m.time,&m.flags);
    m.sel=(uint8_t)inventory_selected();m.pad[0]=m.pad[1]=0;
    int size=sizeof m;
    BFile_Remove(meta_path);
    if(BFile_Create(meta_path,BFile_File,&size)<0)return 0;
    int h=BFile_Open(meta_path,BFile_WriteOnly);
    if(h<0)return 0;
    int ok=BFile_Write(h,&m,sizeof m)>=0;
    BFile_Close(h);
    return ok;
}
int load_game(void){
    if(!world_load())return 0;
    int h=BFile_Open(meta_path,BFile_ReadOnly);
    if(h<0)return 0;
    SaveMeta m;
    if(BFile_Read(h,&m,sizeof m,-1)<0||m.version!=WORLD_SAVE_VERSION){BFile_Close(h);return 0;}
    BFile_Close(h);
    player_import(&m.ps);
    world_rebuild(m.ps.pos.x>>8,m.ps.pos.z>>8);   /* regenere la fenetre autour du joueur, edits reappliques */
    inventory_import(m.inv);
    inventory_select_delta(m.sel%HOTBAR_SLOTS);
    game_import(m.time,m.flags);
    return 1;
}
