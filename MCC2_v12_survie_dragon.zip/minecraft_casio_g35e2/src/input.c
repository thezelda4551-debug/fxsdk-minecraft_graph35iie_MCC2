#include "input.h"
#include <gint/keyboard.h>
#include <gint/keycodes.h>
/* Track the keys used by MCC2 from gint's event queue. This avoids relying on
   a nonexistent keyscan()/keydown_scan() function in gint 2.11.0. */
static struct { int key; unsigned char down; } keys[] = {
 {KEY_UP,0},{KEY_DOWN,0},{KEY_LEFT,0},{KEY_RIGHT,0},{KEY_SHIFT,0},{KEY_ALPHA,0},
 {KEY_EXE,0},{KEY_EXIT,0},{KEY_F1,0},{KEY_F2,0},{KEY_F3,0},{KEY_F4,0},{KEY_F5,0}
};
void input_reset(void){ for(unsigned i=0;i<sizeof keys/sizeof keys[0];i++) keys[i].down=0; }
int input_down(int key){ for(unsigned i=0;i<sizeof keys/sizeof keys[0];i++) if(keys[i].key==key)return keys[i].down; return 0; }
void input_begin_frame(void){
 key_event_t ev;
 while((ev=pollevent()).type!=KEYEV_NONE){
  for(unsigned i=0;i<sizeof keys/sizeof keys[0];i++) if(keys[i].key==ev.key){
   if(ev.type==KEYEV_DOWN) keys[i].down=1;
   else if(ev.type==KEYEV_UP) keys[i].down=0;
  }
 }
}
